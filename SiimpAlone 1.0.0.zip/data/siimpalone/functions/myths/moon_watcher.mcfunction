# ============================================================
# MOON WATCHER - Миф #26
# Наблюдатель Луны
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 26

execute as @a[scores={myth_id=26}] at @s run particle minecraft:glow_squid_ink ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=26}] at @s run playsound minecraft:entity.glow_squid.ambient master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=26}] at @s run tellraw @s {"text":"[Луна]: Я вижу тебя...","color":"#f4f6f7","italic":true}
