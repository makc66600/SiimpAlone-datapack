# ============================================================
# HEADLESS HORSEMAN - Миф #28
# Безголовый Всадник
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 28

execute as @a[scores={myth_id=28}] at @s run particle minecraft:poof ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=28}] at @s run playsound minecraft:entity.horse.gallop master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=28}] at @s run tellraw @s {"text":"[Всадник]: Где моя голова?!","color":"#7f0000","italic":true}
