# ============================================================
# LOST CHILD - Миф #25
# Потерянный Ребёнок
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 25

execute as @a[scores={myth_id=25}] at @s run particle minecraft:heart ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=25}] at @s run playsound minecraft:entity.strider.happy master @s ~ ~ ~ 0.2 0.5
execute as @a[scores={myth_id=25}] at @s run tellraw @s {"text":"[Ребёнок]: Ты видел мою маму?","color":"#ecf0f1","italic":true}
