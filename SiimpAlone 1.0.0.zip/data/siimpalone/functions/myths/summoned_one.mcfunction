# ============================================================
# SUMMONED ONE - Миф #40
# Призванный
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 40

execute as @a[scores={myth_id=40}] at @s run particle minecraft:flash ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=40}] at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=40}] at @s run tellraw @s {"text":"[???]: Наконец-то...","color":"#8e44ad","italic":true}
