# ============================================================
# VOID WHISPER - Миф #35
# Шёпот Пустоты
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 35

execute as @a[scores={myth_id=35}] at @s run particle minecraft:falling_dust minecraft:gray_wool ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=35}] at @s run playsound minecraft:entity.ghast.ambient master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=35}] at @s run tellraw @s {"text":"[Голос]: Приди...","color":"#7f8c8d","italic":true}
