# ============================================================
# CRAWLING HAND - Миф #33
# Ползущая Рука
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 33

execute as @a[scores={myth_id=33}] at @s run particle minecraft:item_slime ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=33}] at @s run playsound minecraft:entity.slime.squish master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=33}] at @s run tellraw @s {"text":"[Рука]: Отдай...","color":"#27ae60","italic":true}
