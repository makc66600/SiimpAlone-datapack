# ============================================================
# SILENT WHISPER - Миф #15
# Тихий Шёпот
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 15

execute as @a[scores={myth_id=15}] at @s run particle minecraft:dust 0.8 0.8 0.8 1 ^ ^ ^3 0.4 0.4 0.4 0.04 4
execute as @a[scores={myth_id=15}] at @s run playsound minecraft:ambient.underwater.enter master @s ~ ~ ~ 0.15 0.3
execute as @a[scores={myth_id=15}] at @s run tellraw @s {"text":"[Шёпот]: Тссс... слушай...","color":"#b8b8b8","italic":true}
