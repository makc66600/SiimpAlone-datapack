# ============================================================
# HOLLOW KNIGHT - Миф #16
# Пустой Рыцарь
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 16

execute as @a[scores={myth_id=16}] at @s run particle minecraft:iron_block ^ ^ ^3 0.5 0.8 0.5 0.05 5
execute as @a[scores={myth_id=16}] at @s run playsound minecraft:entity.iron_golem.attack master @s ~ ~ ~ 0.2 0.2
execute as @a[scores={myth_id=16}] at @s run tellraw @s {"text":"[Рыцарь]: Защитник пустоты...","color":"#8b8b8b","italic":true}
