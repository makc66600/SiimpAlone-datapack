# SiimpAlone - TENTAR
# Паразит из другого мира

# Спавн
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^7 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"Tentar","color":"green","bold":true,"italic":false}',CustomNameVisible:1b,Tags:["siimpalone_myth","tentar"],ArmorItems:[{},{},{},{id:"minecraft:green_wool",Count:1b}]}

# Звук
execute as @a at @s run playsound minecraft:entity.spider.hurt master @s ~ ~ ~ 0.6 0.8

# Эффект
execute as @a at @s run effect give @s minecraft:poison 5 1 true
execute as @a at @s run effect give @s minecraft:hunger 5 2 true

# Сообщение
execute as @a at @s run tellraw @s {"text":"Tentar: \"Я везде...\"","color":"green","italic":true}
