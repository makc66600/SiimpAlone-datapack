# SiimpAlone - VOQUDE
# Бессмертный помощник

# Спавн
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^6 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:0b,CustomName:'{"text":"Voqude","color":"blue","bold":true,"italic":false}',CustomNameVisible:1b,Tags:["siimpalone_myth","voqude"],ArmorItems:[{},{},{},{id:"minecraft:blue_wool",Count:1b}]}

# Звук
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.5 0.3

# Эффект
execute as @a at @s run effect give @s minecraft:regeneration 3 1 true

# Сообщение
execute as @a at @s run tellraw @s {"text":"Voqude: \"Я бессмертен... но ты - нет\"","color":"blue","italic":true}
