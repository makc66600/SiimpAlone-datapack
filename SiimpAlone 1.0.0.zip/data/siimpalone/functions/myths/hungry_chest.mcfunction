# ============================================================
# HUNGRY CHEST - Миф #37
# Голодный Сундук
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 37

execute as @a[scores={myth_id=37}] at @s run particle minecraft:item minecraft:chest ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=37}] at @s run playsound minecraft:block.chest.open master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=37}] at @s run tellraw @s {"text":"[Сундук]: Открой меня...","color":"#d35400","italic":true}
