# ============================================================
# DEEP DARK - Миф #36
# Глубокая Тьма
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 36

execute as @a[scores={myth_id=36}] at @s run particle minecraft:ash ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=36}] at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=36}] at @s run tellraw @s {"text":"[Тьма]: Проваливайся...","color":"#0a0a0a","italic":true}
