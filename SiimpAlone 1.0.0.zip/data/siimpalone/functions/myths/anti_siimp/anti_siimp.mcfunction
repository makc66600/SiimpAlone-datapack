# SiimpAlone - ANTI_SIIMP
# Тёмный близнец

# Спавн
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^5 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:0b,CustomName:'{"text":"Anti_Siimp","color":"dark_red","bold":true,"italic":false}',CustomNameVisible:1b,Tags:["siimpalone_myth","anti_siimp"],ArmorItems:[{},{},{},{id:"minecraft:red_wool",Count:1b}]}

# Звук
execute as @a at @s run playsound minecraft:entity.enderdragon.death master @s ~ ~ ~ 0.6 0.3

# Эффект
execute as @a at @s run effect give @s minecraft:resistance 3 5 true

# Сообщение
execute as @a at @s run tellraw @s {"text":"Anti_Siimp: \"Я - твоя тень...\"","color":"dark_red","italic":true}
