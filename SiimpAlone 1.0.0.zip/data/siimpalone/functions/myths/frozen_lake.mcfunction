# ============================================================
# FROZEN LAKE - Миф #14
# Замёрзшее Озеро
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 14

execute as @a[scores={myth_id=14}] at @s run particle minecraft:snowflake ^ ^ ^3 0.6 0.6 0.6 0.06 6
execute as @a[scores={myth_id=14}] at @s run playsound minecraft:entity.strider.ambient master @s ~ ~ ~ 0.2 0.2
execute as @a[scores={myth_id=14}] at @s run tellraw @s {"text":"[Озеро]: Замёрзшие голоса зовут тебя...","color":"#a5d8ff","italic":true}
