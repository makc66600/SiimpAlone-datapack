# ============================================================
# CURSED WHEEL - Миф #22
# Проклятое Колесо
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 22

execute as @a[scores={myth_id=22}] at @s run particle minecraft:enchant ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=22}] at @s run playsound minecraft:block.ender_chest.open master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=22}] at @s run tellraw @s {"text":"[Колесо]: Вращается... вечно...","color":"#9b59b6","italic":true}
