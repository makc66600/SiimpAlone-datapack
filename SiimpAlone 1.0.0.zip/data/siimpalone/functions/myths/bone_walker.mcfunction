# ============================================================
# BONE WALKER - Миф #12
# Костяной Странник
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 12

execute as @a[scores={myth_id=12}] at @s run particle minecraft:bone_block ^ ^ ^3 0.5 0.5 0.5 0.08 6
execute as @a[scores={myth_id=12}] at @s run playsound minecraft:entity.skeleton_horse.ambient master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=12}] at @s run tellraw @s {"text":"[Костяной]: Я вижу тебя...","color":"#d4c4a8","italic":true}
