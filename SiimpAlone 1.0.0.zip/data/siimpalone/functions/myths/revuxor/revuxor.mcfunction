# SiimpAlone - REVUXOR
# Перевертыш

# Спавн
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^5 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:0b,CustomName:'{"text":"Revuxor","color":"light_purple","bold":true,"italic":false}',CustomNameVisible:1b,Tags:["siimpalone_myth","revuxor"],ArmorItems:[{},{},{},{id:"minecraft:magenta_wool",Count:1b}]}

# Звук
execute as @a at @s run playsound minecraft:entity.ender_eye.death master @s ~ ~ ~ 0.5 0.5

# Эффект
execute as @a at @s run effect give @s minecraft:glowing 3 0 true

# Сообщение
execute as @a at @s run tellraw @s {"text":"Revuxor: \"Всё не то, чем кажется...\"","color":"light_purple","italic":true}
