# ============================================================
# GHOST SHIP - Миф #31
# Корабль-Призрак
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 31

execute as @a[scores={myth_id=31}] at @s run particle minecraft:bubble ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=31}] at @s run playsound minecraft:entity.boat.paddle_land master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=31}] at @s run tellraw @s {"text":"[Корабль]: Я жду тебя...","color":"#1b4f72","italic":true}
