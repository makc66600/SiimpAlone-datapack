# ============================================================
# WANDERING LANTERN - Миф #21
# Блуждающий Фонарь
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 21

execute as @a[scores={myth_id=21}] at @s run particle minecraft:soul_fire_flame ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=21}] at @s run playsound minecraft:block.lantern.break master @s ~ ~ ~ 0.2 0.5
execute as @a[scores={myth_id=21}] at @s run tellraw @s {"text":"[Фонарь]: Найди свет...","color":"#ffa502","italic":true}
