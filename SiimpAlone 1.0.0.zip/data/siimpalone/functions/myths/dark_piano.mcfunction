# ============================================================
# DARK PIANO - Миф #27
# Тёмное Пианино
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 27

execute as @a[scores={myth_id=27}] at @s run particle minecraft:note ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=27}] at @s run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.2 0.5
execute as @a[scores={myth_id=27}] at @s run tellraw @s {"text":"[Пианино]: Мелодия... зовёт...","color":"#1a1a1a","italic":true}
