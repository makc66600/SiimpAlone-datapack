# SiimpAlone - VOID WALKER (Улучшенный)
# Странник Бездны - жуткое существо из пустоты

# Спавн сущности с эффектами
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^3 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"Void Walker","color":"#1a1a2e","bold":true,"italic":false}',CustomNameVisible:1b,Tags:["siimpalone_myth","void_walker"],ArmorItems:[{},{},{},{id:"minecraft:black_wool",Count:1b}],Pose:{Head:[0f,0f,0f]}}

# Частицы бездны
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^1 0.5 1 0.5 0.1 10 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^ ^0.5 0.3 0.3 0.3 0.05 5 force

# Жуткий звук с эхо
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.7 0.1
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 0.3 0.5

# Эффекты на игрока
execute as @a at @s run effect give @s minecraft:blindness 5 0 true
execute as @a at @s run effect give @s minecraft:slowness 3 1 true
execute as @a at @s run effect give @s minecraft:wither 3 0 true

# Телепортация за спину
execute as @a at @s run teleport @e[tag=void_walker] ~ ~ ~-2

# Жуткое сообщение
execute as @a at @s run tellraw @s {"text":"[Void Walker]: Ты не должен был видеть меня...","color":"#4a4e69","italic":true,"bold":false}

# Удаление через время
execute as @e[tag=void_walker] run schedule function siimpalone:myths/void_walker_despawn 10s

