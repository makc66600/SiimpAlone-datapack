# ============================================================
# VOID WALKER - Message 2
# Второе сообщение
# ============================================================

execute as @a at @s run tellraw @s {"text":"[Void Walker]: Ты чувствуешь холод?","color":"#4a4e69","italic":true}
execute as @a at @s run playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 0.2 0.3
execute as @a at @s run effect give @s minecraft:darkness 2 0 true
