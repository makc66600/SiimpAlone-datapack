# ============================================================
# VOID WALKER - Title 2
# Второй заголовок
# ============================================================

execute as @a at @s run title @s title {"text":"","color":"black"}
execute as @a at @s run title @s subtitle {"text":"Оно приближается...","color":"#1a1a2e","italic":true}
execute as @a at @s run title @s times 0 25 8
