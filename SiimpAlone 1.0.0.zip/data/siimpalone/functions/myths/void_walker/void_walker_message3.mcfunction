# Void Walker Message 3
execute as @a at @s run tellraw @s {"text":"[Void Walker]: Скоро ты познаешь пустоту...","color":"#4a4e69","italic":true}
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 0.3 0.2
