# ============================================================
# VOID WALKER - Atmosphere 3
# Атмосфера 3
# ============================================================

execute as @a at @s run particle minecraft:smoke ^ ^ ^4 1.2 1.2 1.2 0.12 6
execute as @a at @s run particle minecraft:shadow ^ ^ ^4 0.6 0.6 0.6 0.06 5
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 0.1 0.4
execute as @a at @s run effect give @s minecraft:darkness 3 0 true
