# ============================================================
# VOID WALKER - Atmosphere 2
# Атмосфера 2
# ============================================================

execute as @a at @s run particle minecraft:smoke ^ ^ ^3 1 1 1 0.1 5
execute as @a at @s run particle minecraft:shadow ^ ^ ^3 0.5 0.5 0.5 0.05 4
execute as @a at @s run playsound minecraft:block.nether_portal.ambient master @s ~ ~ ~ 0.1 0.2
execute as @a at @s run effect give @s minecraft:darkness 2 0 true
