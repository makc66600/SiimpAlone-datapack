# ============================================================
# VOID WALKER - Phase 3
# Фаза 3 - пиковая интенсивность
# ============================================================

# Intense portal particles
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^3 1 1 1 0.2 15 force

# Explosion particles
execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^ ^ ^ 0.5 0.5 0.5 0.05 3 force

# Dragon breath
execute as @e[tag=void_walker] at @s run particle minecraft:dragon_breath ^ ^ ^1 0.4 0.4 0.4 0.06 5 force

# Clone intense particles
execute as @e[tag=void_walker_clone1] at @s run particle minecraft:shadow ^ ^ ^0.5 0.3 0.3 0.03 5 force
execute as @e[tag=void_walker_clone2] at @s run particle minecraft:shadow ^ ^ ^0.5 0.3 0.3 0.03 5 force

# Sound
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.4 0.08
execute as @a at @s run playsound minecraft:block.nether_portal.trigger master @s ~ ~ ~ 0.2 0.3

# Player effects
execute as @a at @s run effect give @s minecraft:blindness 3 0 true
execute as @a at @s run effect give @s minecraft:darkness 5 0 true
execute as @a at @s run effect give @s minecraft:wither 3 0 true
execute as @a at @s run effect give @s minecraft:nausea 3 0 true

# Damage
execute as @a at @s run damage @s 1 minecraft:void
