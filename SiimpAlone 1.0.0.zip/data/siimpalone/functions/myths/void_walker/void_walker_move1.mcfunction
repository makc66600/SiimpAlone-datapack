# Void Walker Move 1 - Circle around player
execute as @e[tag=void_walker] at @s run teleport @s ^0.5 ^ ^0.5
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^0.3 0.3 0.3 0.3 0.05 5 force
