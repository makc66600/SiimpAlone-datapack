# Void Walker Message 4
execute as @a at @s run tellraw @s {"text":"[Void Walker]: Вечность ждёт тебя...","color":"#4a4e69","italic":true}
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.2 0.1
