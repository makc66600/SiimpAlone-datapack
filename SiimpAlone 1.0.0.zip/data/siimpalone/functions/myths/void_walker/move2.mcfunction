# ============================================================
# VOID WALKER - Move 2
# Второе перемещение - окружение
# ============================================================

# Move main entity
execute as @e[tag=void_walker] at @p run teleport @s ^ ^ ^1
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^0.5 0.5 0.5 0.1 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^ ^0.3 0.3 0.3 0.05 4

# Move clones to surround
execute as @e[tag=void_walker_clone1] at @p run teleport @s ^2 ^ ^-1
execute as @e[tag=void_walker_clone2] at @p run teleport @s ^-2 ^ ^-1
execute as @e[tag=void_walker_clone3] at @p run teleport @s ^1 ^ ^-2
execute as @e[tag=void_walker_clone4] at @p run teleport @s ^-1 ^ ^-2

# Clone particles
execute as @e[tag=void_walker_clone1] at @s run particle minecraft:smoke ^ ^ ^0.2 0.2 0.2 0.03 4
execute as @e[tag=void_walker_clone2] at @s run particle minecraft:smoke ^ ^ ^0.2 0.2 0.2 0.03 4
execute as @e[tag=void_walker_clone3] at @s run particle minecraft:smoke ^ ^ ^0.2 0.2 0.2 0.03 4
execute as @e[tag=void_walker_clone4] at @s run particle minecraft:smoke ^ ^ ^0.2 0.2 0.2 0.03 4

# Sound effects
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 0.15 0.5

# Player effects
execute as @a at @s run effect give @s minecraft:wither 2 0 true
execute as @a at @s run effect give @s minecraft:slowness 2 0 true
