# ============================================================
# VOID WALKER - Move 4
# Четвёртое перемещение - финальная атака
# ============================================================

# Move main entity very close
execute as @e[tag=void_walker] at @p run teleport @s ^ ^ ^0.3
execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^ ^ ^ 0.5 0.5 0.5 0.05 3 force

# All clones surround player
execute as @e[tag=void_walker_clone1] at @p run teleport @s ^1 ^0.5 ^
execute as @e[tag=void_walker_clone2] at @p run teleport @s ^-1 ^0.5 ^
execute as @e[tag=void_walker_clone3] at @p run teleport @s ^ ^0.5 ^1
execute as @e[tag=void_walker_clone4] at @p run teleport @s ^ ^0.5 ^-1

# Final attack particles
execute as @e[tag=void_walker] at @s run particle minecraft:large_smoke ^ ^ ^ 0.5 0.5 0.5 0.08 6
execute as @e[tag=void_walker] at @s run particle minecraft:dragon_breath ^ ^ ^0.5 0.5 0.5 0.06 5 force

# Final sound
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.3 0.1

# Damage
execute as @a at @s run damage @s 2 minecraft:void

# Final player effects
execute as @a at @s run effect give @s minecraft:wither 3 0 true
execute as @a at @s run effect give @s minecraft:blindness 3 0 true
