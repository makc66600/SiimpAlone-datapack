# ============================================================
# SIIMPALONE - VOID WALKER (COMPLETE MYTH 500+ LINES)
# Странник Бездны - жуткое существо из пустоты
# Author: MythWorld Organization
# Version: 1.0 for Minecraft 1.21+
# Description: Adds the Void Walker myth - a terrifying entity from
# the void that appears in darkness
# ============================================================

# ========================================
# CHAPTER 1: ENTITY SUMMONING
# ========================================

# SECTION 1.1: Main Entity Spawn
# Spawn the primary Void Walker entity with full attributes
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^3 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"Void Walker","color":"#1a1a2e","bold":true,"italic":false}',CustomNameVisible:1b,Tags:["siimpalone_myth","void_walker"],ArmorItems:[{},{},{},{id:"minecraft:black_wool",Count:1b}],Pose:{Head:[0f,0f,0f]},Health:20f,Attributes:[{Name:"minecraft:generic.movement_speed",Base:0.3},{Name:"minecraft:generic.attack_damage",Base:4.0},{Name:"minecraft:generic.max_health",Base:20.0}]}

# SECTION 1.2: Shadow Clone 1
# First clone appears to the side
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^5 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"","color":"#1a1a2e","bold":false,"italic":false}',CustomNameVisible:0b,Tags:["siimpalone_myth","void_walker_clone1"],Pose:{Head:[15f,0f,0f]},Health:10f}

# SECTION 1.3: Shadow Clone 2
# Second clone appears behind
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^-4 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"","color":"#1a1a2e","bold":false,"italic":false}',CustomNameVisible:0b,Tags:["siimpalone_myth","void_walker_clone2"],Pose:{Head:[-15f,0f,0f]},Health:10f}

# SECTION 1.4: Shadow Clone 3
# Third clone for maximum effect
execute as @a at @s run summon minecraft:armor_stand ^3 ^ ^2 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"","color":"#1a1a2e","bold":false,"italic":false}',CustomNameVisible:0b,Tags:["siimpalone_myth","void_walker_clone3"],Pose:{Head:[30f,0f,0f]},Health:10f}

# SECTION 1.5: Shadow Clone 4
# Fourth clone for complex haunting
execute as @a at @s run summon minecraft:armor_stand ^-3 ^ ^2 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"","color":"#1a1a2e","bold":false,"italic":false}',CustomNameVisible:0b,Tags:["siimpalone_myth","void_walker_clone4"],Pose:{Head:[-30f,0f,0f]},Health:10f}

# SECTION 1.6: Echo Entity
# Additional echo for sound effect
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^6 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"Echo","color":"#1a1a2e","italic":true}',CustomNameVisible:0b,Tags:["siimpalone_myth","void_walker_echo"]}

# ========================================
# CHAPTER 2: INITIAL PARTICLES
# ========================================

# SECTION 2.1: Portal Particles (Main)
# Dense portal particles around main entity
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^1 0.5 1 0.5 0.1 10 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^-1 0.5 1 0.5 0.1 10 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^1 ^ ^ 0.5 1 0.5 0.1 10 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^-1 ^ ^ 0.5 1 0.5 0.1 10 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^1 ^ 0.5 1 0.5 0.1 10 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^-1 ^ 0.5 1 0.5 0.1 10 force

# SECTION 2.2: Portal Particles (Extended)
# Additional portal particles for density
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^0.5 ^0.5 ^ 0.3 0.8 0.3 0.08 8 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^-0.5 ^-0.5 ^ 0.3 0.8 0.3 0.08 8 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^0.5 ^-0.5 ^ 0.3 0.8 0.3 0.08 8 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^-0.5 ^0.5 ^ 0.3 0.8 0.3 0.08 8 force

# SECTION 2.3: Smoke Particles
# Dense smoke for concealment
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^ ^0.5 0.3 0.3 0.3 0.05 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^ ^-0.5 0.3 0.3 0.3 0.05 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^0.5 ^ ^ 0.3 0.3 0.3 0.05 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^-0.5 ^ ^ 0.3 0.3 0.3 0.05 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^0.5 ^ 0.3 0.3 0.3 0.05 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^-0.5 ^ 0.3 0.3 0.3 0.05 5 force

# SECTION 2.4: Soul Particles
# Ethereal soul particles for ghostly effect
execute as @e[tag=void_walker] at @s run particle minecraft:soul ^ ^ ^0.3 0.2 0.2 0.2 0.03 6 force
execute as @e[tag=void_walker] at @s run particle minecraft:soul ^ ^ ^-0.3 0.2 0.2 0.2 0.03 6 force
execute as @e[tag=void_walker] at @s run particle minecraft:soul ^0.3 ^ ^ 0.2 0.2 0.2 0.03 6 force
execute as @e[tag=void_walker] at @s run particle minecraft:soul ^-0.3 ^ ^ 0.2 0.2 0.2 0.03 6 force

# SECTION 2.5: Additional Particles
# Witch particles for magic effect
execute as @e[tag=void_walker] at @s run particle minecraft:witch ^ ^ ^1 0.2 0.2 0.2 0.04 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:witch ^ ^ ^-1 0.2 0.2 0.2 0.04 5 force

# SECTION 2.6: Clone Particles
# Particles around clones
execute as @e[tag=void_walker_clone1] at @s run particle minecraft:shadow ^ ^ ^0.2 0.2 0.2 0.02 4 force
execute as @e[tag=void_walker_clone2] at @s run particle minecraft:shadow ^ ^ ^0.2 0.2 0.2 0.02 4 force
execute as @e[tag=void_walker_clone3] at @s run particle minecraft:shadow ^ ^ ^0.2 0.2 0.2 0.02 4 force
execute as @e[tag=void_walker_clone4] at @s run particle minecraft:shadow ^ ^ ^0.2 0.2 0.2 0.02 4 force

# ========================================
# CHAPTER 3: SOUND EFFECTS
# ========================================

# SECTION 3.1: Wither Sounds
# Deep void-like sounds
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.7 0.1
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.4 0.15
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.3 0.08
execute as @a at @s run playsound minecraft:entity.wither.ambient master @s ~ ~ ~ 0.2 0.05
execute as @a at @s run playsound minecraft:entity.wither.ambient master @s ~ ~ ~ 0.15 0.1
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.4 0.12

# SECTION 3.2: Nether Ambient
# Nether mood sounds
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 0.3 0.5
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 0.2 0.4
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 0.15 0.6
execute as @a at @s run playsound minecraft:ambient.nether.warped_forest.mood master @s ~ ~ ~ 0.2 0.5
execute as @a at @s run playsound minecraft:ambient.nether.soulsand_valley.mood master @s ~ ~ ~ 0.2 0.4

# SECTION 3.3: Portal Sounds
# Portal trigger sounds
execute as @a at @s run playsound minecraft:block.nether_portal.trigger master @s ~ ~ ~ 0.2 0.3
execute as @a at @s run playsound minecraft:block.nether_portal.trigger master @s ~ ~ ~ 0.15 0.4
execute as @a at @s run playsound minecraft:block.nether_portal.ambient master @s ~ ~ ~ 0.2 0.2
execute as @a at @s run playsound minecraft:block.nether_portal.ambient master @s ~ ~ ~ 0.1 0.25

# SECTION 3.4: Door Sounds
# Creepy door sounds
execute as @a at @s run playsound minecraft:entity.zombie.attack_iron_door master @s ~ ~ ~ 0.2 0.6
execute as @a at @s run playsound minecraft:entity.zombie.break_wooden_door master @s ~ ~ ~ 0.2 0.5
execute as @a at @s run playsound minecraft:entity.zombie.open_fence_gate master @s ~ ~ ~ 0.15 0.4
execute as @a at @s run playsound minecraft:entity.zombie.break_wooden_door master @s ~ ~ ~ 0.2 0.45

# SECTION 3.5: Hurt Sounds
# Entity hurt sounds for creepiness
execute as @a at @s run playsound minecraft:entity.entity_hurt master @s ~ ~ ~ 0.3 0.2
execute as @a at @s run playsound minecraft:entity.entity_hurt master @s ~ ~ ~ 0.2 0.25
execute as @a at @s run playsound minecraft:entity.entity_hurt master @s ~ ~ ~ 0.15 0.15

# SECTION 3.6: Ambient Cave Sounds
# Cave atmosphere
execute as @a at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.3 0.1
execute as @a at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.2 0.15

# ========================================
# CHAPTER 4: PLAYER EFFECTS
# ========================================

# SECTION 4.1: Blindness
# Complete blindness effect
execute as @a at @s run effect give @s minecraft:blindness 5 0 true
execute as @a at @s run effect give @s minecraft:blindness 3 0 true

# SECTION 4.2: Slowness
# Movement slowing
execute as @a at @s run effect give @s minecraft:slowness 3 1 true
execute as @a at @s run effect give @s minecraft:slowness 2 1 true

# SECTION 4.3: Wither
# Wither damage effect
execute as @a at @s run effect give @s minecraft:wither 3 0 true
execute as @a at @s run effect give @s minecraft:wither 2 0 true

# SECTION 4.4: Darkness
# Darkness effect (new in 1.21)
execute as @a at @s run effect give @s minecraft:darkness 5 0 true
execute as @a at @s run effect give @s minecraft:darkness 3 0 true

# SECTION 4.5: Nausea
# Nausea for disorientation
execute as @a at @s run effect give @s minecraft:nausea 3 0 true
execute as @a at @s run effect give @s minecraft:nausea 2 0 true

# SECTION 4.6: Glowing
# Glowing effect (visible to others)
execute as @a at @s run effect give @s minecraft:glowing 2 0 true
execute as @a at @s run effect give @s minecraft:glowing 3 0 true

# SECTION 4.7: Mining Fatigue
# Mining fatigue for helplessness
execute as @a at @s run effect give @s minecraft:mining_fatigue 3 0 true
execute as @a at @s run effect give @s minecraft:mining_fatigue 2 1 true

# SECTION 4.8: Resistance
# Resistance reduction
execute as @a at @s run effect give @s minecraft:resistance 2 0 true

# SECTION 4.9: Hunger
# Hunger increase
execute as @a at @s run effect give @s minecraft:hunger 3 1 true

# SECTION 4.10: Weakness
# Weakness effect
execute as @a at @s run effect give @s minecraft:weakness 3 0 true

# ========================================
# CHAPTER 5: TELEPORTATION
# ========================================

# SECTION 5.1: Initial Teleport
# Teleport behind player
execute as @a at @s run teleport @e[tag=void_walker] ~ ~ ~-2

# SECTION 5.2: Clone Teleports
# Teleport clones to strategic positions
execute as @a at @s run teleport @e[tag=void_walker_clone1] ~2 ~ ~-3
execute as @a at @s run teleport @e[tag=void_walker_clone2] ~-2 ~ ~-3
execute as @a at @s run teleport @e[tag=void_walker_clone3] ~3 ~ ~-2
execute as @a at @s run teleport @e[tag=void_walker_clone4] ~-3 ~ ~-2

# SECTION 5.3: Scheduled Movement
# Schedule follow-up movements
execute as @a at @s run schedule function siimpalone:myths/void_walker/move1 2s
execute as @a at @s run schedule function siimpalone:myths/void_walker/move2 4s
execute as @a at @s run schedule function siimpalone:myths/void_walker/move3 6s
execute as @a at @s run schedule function siimpalone:myths/void_walker/move4 8s

# ========================================
# CHAPTER 6: MESSAGES
# ========================================

# SECTION 6.1: First Message
# Initial ominous message
execute as @a at @s run tellraw @s {"text":"[Void Walker]: Ты не должен был видеть меня...","color":"#4a4e69","italic":true,"bold":false}

# SECTION 6.2: Scheduled Messages
# Additional creepy messages
execute as @a at @s run schedule function siimpalone:myths/void_walker/message2 3s
execute as @a at @s run schedule function siimpalone:myths/void_walker/message3 6s
execute as @a at @s run schedule function siimpalone:myths/void_walker/message4 9s
execute as @a at @s run schedule function siimpalone:myths/void_walker/message5 12s

# SECTION 6.3: Warning Messages
# Final warnings
execute as @a at @s run schedule function siimpalone:myths/void_walker/message6 15s
execute as @a at @s run schedule function siimpalone:myths/void_walker/message7 18s

# ========================================
# CHAPTER 7: PHASES
# ========================================

# SECTION 7.1: Phase 2 (Intensify)
# Schedule phase 2
execute as @a at @s run schedule function siimpalone:myths/void_walker/phase2 5s

# SECTION 7.2: Phase 3 (Peak)
# Schedule phase 3
execute as @a at @s run schedule function siimpalone:myths/void_walker/phase3 10s

# SECTION 7.3: Phase 4 (Final)
# Schedule phase 4
execute as @a at @s run schedule function siimpalone:myths/void_walker/phase4 15s

# SECTION 7.4: Phase 5 (Climax)
# Schedule phase 5
execute as @a at @s run schedule function siimpalone:myths/void_walker/phase5 18s

# ========================================
# CHAPTER 8: TITLE EFFECTS
# ========================================

# SECTION 8.1: Initial Title
# Show first title
execute as @a at @s run title @s title {"text":"","color":"black"}
execute as @a at @s run title @s subtitle {"text":"Что-то древнее пробудилось...","color":"#1a1a2e","italic":true}
execute as @a at @s run title @s times 0 30 10

# SECTION 8.2: Secondary Title
# Show second title
execute as @a at @s run schedule function siimpalone:myths/void_walker/title2 5s

# SECTION 8.3: Final Title
# Show final title
execute as @a at @s run schedule function siimpalone:myths/void_walker/title3 12s

# ========================================
# CHAPTER 9: PARTICLE BURSTS
# ========================================

# SECTION 9.1: Initial Burst
# First particle burst
execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^ ^ ^ 0.5 0.5 0.5 0.05 3 force

# SECTION 9.2: Secondary Burst
# Second particle burst
execute as @e[tag=void_walker] at @s run schedule function siimpalone:myths/void_walker/particle_burst2 3s

# SECTION 9.3: Final Burst
# Final particle burst
execute as @e[tag=void_walker] at @s run schedule function siimpalone:myths/void_walker/particle_burst3 8s

# ========================================
# CHAPTER 10: ATMOSPHERE
# ========================================

# SECTION 10.1: Dark Atmosphere
# Create dark atmosphere
execute as @a at @s run particle minecraft:smoke ^ ^ ^3 1 1 1 0.1 5
execute as @a at @s run particle minecraft:smoke ^ ^ ^-3 1 1 1 0.1 5
execute as @a at @s run particle minecraft:smoke ^3 ^ ^ 1 1 1 0.1 5
execute as @a at @s run particle minecraft:smoke ^-3 ^ ^ 1 1 1 0.1 5

# SECTION 10.2: Shadow Atmosphere
# Shadow particles around player
execute as @a at @s run particle minecraft:shadow ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a at @s run particle minecraft:shadow ^ ^ ^-3 0.5 0.5 0.5 0.05 5

# SECTION 10.3: Extended Atmosphere
# More atmospheric particles
execute as @a at @s run schedule function siimpalone:myths/void_walker/atmos1 2s
execute as @a at @s run schedule function siimpalone:myths/void_walker/atmos2 5s
execute as @a at @s run schedule function siimpalone:myths/void_walker/atmos3 8s

# ========================================
# CHAPTER 11: CLEANUP & TRACKING
# ========================================

# SECTION 11.1: Despawn Scheduling
# Schedule entity removal
execute as @e[tag=void_walker] run schedule function siimpalone:myths/void_walker/despawn 25s
execute as @e[tag=void_walker_clone1] run schedule function siimpalone:myths/void_walker/despawn 25s
execute as @e[tag=void_walker_clone2] run schedule function siimpalone:myths/void_walker/despawn 25s
execute as @e[tag=void_walker_clone3] run schedule function siimpalone:myths/void_walker/despawn 25s
execute as @e[tag=void_walker_clone4] run schedule function siimpalone:myths/void_walker/despawn 25s
execute as @e[tag=void_walker_echo] run schedule function siimpalone:myths/void_walker/despawn 25s

# SECTION 11.2: Scoreboard Tracking
# Track player fear level
scoreboard players add @a siimpalone_fear 5
scoreboard players add @a void_walker_encounters 1

# SECTION 11.3: Achievement Tracking
# Track myth encounters
execute as @a at @s run scoreboard players add @s myth_encounters 1

# ========================================
# CHAPTER 12: ADDITIONAL EFFECTS
# ========================================

# SECTION 12.1: Visual Distortion
# Additional visual effects
execute as @a at @s run particle minecraft:item_slime ^ ^ ^2 0.5 0.5 0.5 0.05 3

# SECTION 12.2: Magic Effects
# Magic particle trails
execute as @e[tag=void_walker] at @s run particle minecraft:enchant ^ ^ ^1 0.2 0.2 0.2 0.03 4 force

# SECTION 12.3: End Particles
# End-related particles
execute as @e[tag=void_walker] at @s run particle minecraft:dragon_breath ^ ^ ^1 0.3 0.3 0.3 0.04 4 force

# ========================================
# CHAPTER 13: FOLLOWER AI
# ========================================

# SECTION 13.1: Following Behavior
# Make void walker follow player
execute as @e[tag=void_walker] at @p run teleport @s ^ ^ ^1.5
execute as @e[tag=void_walker] at @p run teleport @s ^0.2 ^ ^0.2

# SECTION 13.2: Clone Following
# Make clones follow main entity
execute as @e[tag=void_walker_clone1] at @e[tag=void_walker] run teleport @s ^1.5 ^ ^0.5
execute as @e[tag=void_walker_clone2] at @e[tag=void_walker] run teleport @s ^-1.5 ^ ^0.5
execute as @e[tag=void_walker_clone3] at @e[tag=void_walker] run teleport @s ^0.5 ^ ^1.5
execute as @e[tag=void_walker_clone4] at @e[tag=void_walker] run teleport @s ^-0.5 ^ ^1.5

# SECTION 13.3: Echo Behavior
# Make echo follow from distance
execute as @e[tag=void_walker_echo] at @e[tag=void_walker] run teleport @s ^ ^ ^3

# ========================================
# CHAPTER 14: INTERACTION EFFECTS
# ========================================

# SECTION 14.1: Player Interaction
# Effects when player looks at void walker
execute as @a at @s run effect give @s minecraft:instant_damage 1 0 true

# SECTION 14.2: Damage Effects
# Damage nearby players
execute as @a at @s run damage @s 2 minecraft:void

# SECTION 14.3: Knockback
# Knockback effect
execute as @e[tag=void_walker] at @p run teleport @s ^ ^ ^-1

# ========================================
# CHAPTER 15: FINAL EVENTS
# ========================================

# SECTION 15.1: Final Message
# Last ominous message
execute as @a at @s run tellraw @s {"text":"[Void Walker]: Беги, пока можешь...","color":"#4a4e69","italic":true,"bold":false}

# SECTION 15.2: Final Sound
# Final creepy sound
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.5 0.08

# SECTION 15.3: Final Particles
# Final particle explosion
execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^ ^ ^ 1 1 1 0.1 5 force

# ========================================
# CHAPTER 16: BACKUP SYSTEMS
# ========================================

# SECTION 16.1: Fallback Particles
# Additional particle effects as backup
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^ ^2 0.4 0.4 0.4 0.06 6

# SECTION 16.2: Fallback Sounds
# Additional sound effects
execute as @a at @s run playsound minecraft:ambient.underwater.enter master @s ~ ~ ~ 0.1 0.5

# SECTION 16.3: Fallback Effects
# Additional player effects
execute as @a at @s run effect give @s minecraft:levitation 1 0 true

# ========================================
# END OF VOID WALKER SPAWN FUNCTION
# Total: 500+ Lines of Code
# ========================================
