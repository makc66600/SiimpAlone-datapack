# ============================================================
# VOID WALKER - Phase 2
# Фаза 2 - усиление
# ============================================================

# More portal particles
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^2 0.8 1 0.8 0.15 12 force

# Soul particles
execute as @e[tag=void_walker] at @s run particle minecraft:soul ^ ^ ^1 0.3 0.3 0.3 0.05 8 force

# Witch particles
execute as @e[tag=void_walker] at @s run particle minecraft:witch ^ ^ ^1 0.3 0.3 0.3 0.05 6 force

# Clone particles
execute as @e[tag=void_walker_clone1] at @s run particle minecraft:smoke ^ ^ ^0.5 0.3 0.3 0.03 5
execute as @e[tag=void_walker_clone2] at @s run particle minecraft:smoke ^ ^ ^0.5 0.3 0.3 0.03 5

# Sound effects
execute as @a at @s run playsound minecraft:block.nether_portal.ambient master @s ~ ~ ~ 0.2 0.2
execute as @a at @s run playsound minecraft:entity.wither.ambient master @s ~ ~ ~ 0.2 0.1

# Player effects
execute as @a at @s run effect give @s minecraft:darkness 3 0 true
execute as @a at @s run effect give @s minecraft:slowness 3 1 true
execute as @a at @s run effect give @s minecraft:wither 2 0 true
