# ============================================================
# VOID WALKER - Particle Burst 2
# Второй взрыв частиц
# ============================================================

execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^2 0.8 0.8 0.8 0.1 8 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^ ^1 0.5 0.5 0.5 0.08 6
