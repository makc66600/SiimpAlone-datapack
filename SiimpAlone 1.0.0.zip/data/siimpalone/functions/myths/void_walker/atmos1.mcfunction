# ============================================================
# VOID WALKER - Atmosphere 1
# Атмосфера 1
# ============================================================

execute as @a at @s run particle minecraft:smoke ^ ^ ^2 0.8 0.8 0.8 0.08 4
execute as @a at @s run particle minecraft:shadow ^ ^ ^2 0.4 0.4 0.4 0.04 3
execute as @a at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.1 0.1
