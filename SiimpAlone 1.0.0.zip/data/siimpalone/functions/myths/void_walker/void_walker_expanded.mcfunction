# SiimpAlone - VOID WALKER (Expanded 300+ lines)
# Странник Бездны - жуткое существо из пустоты
# Expanded version with maximum horror effects

# ========================================
# SECTION 1: INITIAL SUMMON
# ========================================

# Main spawn entity with full custom attributes
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^3 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"Void Walker","color":"#1a1a2e","bold":true,"italic":false}',CustomNameVisible:1b,Tags:["siimpalone_myth","void_walker"],ArmorItems:[{},{},{},{id:"minecraft:black_wool",Count:1b}],Pose:{Head:[0f,0f,0f]},Health:20f,Attributes:[{Name:"minecraft:generic.movement_speed",Base:0.2},{Name:"minecraft:generic.attack_damage",Base:5.0}]}

# Secondary clone for fear effect
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^5 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"Void Walker","color":"#1a1a2e","bold":true,"italic":false}',CustomNameVisible:0b,Tags:["siimpalone_myth","void_walker_clone"],ArmorItems:[{},{},{},{id:"minecraft:black_wool",Count:1b}]}

# ========================================
# SECTION 2: PARTICLE EFFECTS - PHASE 1
# ========================================

# Portal particles around the entity
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^1 0.5 1 0.5 0.1 10 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^-1 0.5 1 0.5 0.1 10 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^1 ^ ^ 0.5 1 0.5 0.1 10 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^-1 ^ ^ 0.5 1 0.5 0.1 10 force

# Smoke effects for mysterious atmosphere
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^ ^0.5 0.3 0.3 0.3 0.05 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^ ^-0.5 0.3 0.3 0.3 0.05 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^0.5 ^ ^ 0.3 0.3 0.3 0.05 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^-0.5 ^ ^ 0.3 0.3 0.3 0.05 5 force

# Soul flames for dark aura
execute as @e[tag=void_walker] at @s run particle minecraft:soul_fire_flame ^ ^ ^0.3 0.2 0.2 0.2 0.02 8 force
execute as @e[tag=void_walker] at @s run particle minecraft:soul_fire_flame ^ ^ ^-0.3 0.2 0.2 0.2 0.02 8 force

# ========================================
# SECTION 3: SOUND EFFECTS - INITIAL
# ========================================

# Main spawn sound - wither emergence
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.7 0.1
execute as @a at @s run playsound minecraft:entity.wither.ambient master @s ~ ~ ~ 0.5 0.2

# Ambient nether sounds
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 0.3 0.5
execute as @a at @s run playsound minecraft:ambient.nether.soul_forest.valley master @s ~ ~ ~ 0.2 0.3

# Dark ambient
execute as @a at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.4 0.1
execute as @a at @s run playsound minecraft:ambient.underwater.enter master @s ~ ~ ~ 0.3 0.8

# ========================================
# SECTION 4: PLAYER EFFECTS - INITIAL
# ========================================

# Blindness for disorientation
execute as @a at @s run effect give @s minecraft:blindness 5 0 true
execute as @a at @s run effect give @s minecraft:blindness 3 1 true

# Movement slowing
execute as @a at @s run effect give @s minecraft:slowness 3 1 true
execute as @a at @s run effect give @s minecraft:slowness 2 2 true

# Wither effect for damage
execute as @a at @s run effect give @s minecraft:wither 3 0 true
execute as @a at @s run effect give @s minecraft:wither 2 1 true

# Darkness effect
execute as @a at @s run effect give @s minecraft:darkness 5 0 true

# Nausea for disorientation
execute as @a at @s run effect give @s minecraft:nausea 3 0 true

# ========================================
# SECTION 5: TELEPORTATION SEQUENCE
# ========================================

# Teleport behind player
execute as @a at @s run teleport @e[tag=void_walker] ~ ~ ~-2
execute as @a at @s run teleport @e[tag=void_walker_clone] ~ ~2 ~

# Additional teleport effects
execute as @a at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.6 0.1
execute as @a at @s run playsound minecraft:entity.phantom.death master @s ~ ~ ~ 0.4 0.3

# ========================================
# SECTION 6: PARTICLE EFFECTS - PHASE 2
# ========================================

# More portal particles after teleport
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^2 0.8 0.8 0.8 0.15 15 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^-2 0.8 0.8 0.8 0.15 15 force

# Purple mystical particles
execute as @e[tag=void_walker] at @s run particle minecraft:witch ^ ^ ^1 0.4 0.4 0.4 0.08 10 force
execute as @e[tag=void_walker] at @s run particle minecraft:witch ^ ^ ^-1 0.4 0.4 0.4 0.08 10 force

# ========================================
# SECTION 7: MESSAGE SEQUENCE
# ========================================

# Main ominous message
execute as @a at @s run tellraw @s {"text":"[Void Walker]: Ты не должен был видеть меня...","color":"#4a4e69","italic":true,"bold":false}

# Additional whispering messages
execute as @a at @s run tellraw @s {"text":"Бездна смотрит...","color":"#2b2d42","italic":true}
execute as @a at @s run tellraw @s {"text":"Ты теперь часть меня...","color":"#1a1a2e","italic":true}

# Schedule follow-up messages
execute as @a at @s run schedule function siimpalone:myths/void_walker_message2 3s
execute as @a at @s run schedule function siimpalone:myths/void_walker_message3 6s
execute as @a at @s run schedule function siimpalone:myths/void_walker_message4 9s

# ========================================
# SECTION 8: ADDITIONAL SOUNDS
# ========================================

# Creepy ambient sounds
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.3 0.2
execute as @a at @s run playsound minecraft:entity.wither.hurt master @s ~ ~ ~ 0.2 0.3

# More nether sounds
execute as @a at @s run playsound minecraft:ambient.nether.basalt_deltas.mood master @s ~ ~ ~ 0.3 0.4
execute as @a at @s run playsound minecraft:ambient.nether.warped_forest.mood master @s ~ ~ ~ 0.2 0.5

# ========================================
# SECTION 9: SECOND WAVE EFFECTS
# ========================================

# More particle bursts
execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^ ^ ^ 1 1 1 0.1 3 force
execute as @e[tag=void_walker] at @s run particle minecraft:large_smoke ^ ^ ^ 0.5 0.5 0.5 0.1 8 force

# Additional player effects
execute as @a at @s run effect give @s minecraft:resistance 2 0 true
execute as @a at @s run effect give @s minecraft:hunger 3 1 true
execute as @a at @s run effect give @s minecraft:mining_fatigue 3 1 true

# ========================================
# SECTION 10: MOVEMENT EFFECTS
# ========================================

# Circle around player
execute as @e[tag=void_walker] at @s run teleport @s ^ ^ ^0.5

# Schedule movement patterns
execute as @a at @s run schedule function siimpalone:myths/void_walker_move1 1s
execute as @a at @s run schedule function siimpalone:myths/void_walker_move2 2s
execute as @a at @s run schedule function siimpalone:myths/void_walker_move3 3s

# ========================================
# SECTION 11: ATMOSPHERIC EFFECTS
# ========================================

# Change sky (if possible through effects)
execute as @a at @s run particle minecraft:dragon_breath ^ ^ ^5 1 1 1 0.05 5

# More darkness
execute as @a at @s run particle minecraft:smoke ^ ^ ^3 2 2 2 0.1 10

# ========================================
# SECTION 12: FINAL PHASE
# ========================================

# Final sound burst
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.5 0.05

# Last particle burst
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^ 1 1 1 0.2 20 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^ ^ 0.8 0.8 0.8 0.1 15 force

# ========================================
# SECTION 13: ENTITY TRACKING
# ========================================

# Track player position
execute as @e[tag=void_walker] at @s run data modify entity @s Pos[0] set from entity @a[limit=1] Pos[0]
execute as @e[tag=void_walker] at @s run data modify entity @s Pos[2] set from entity @a[limit=1] Pos[2]

# Make clone follow
execute as @e[tag=void_walker_clone] at @s run data modify entity @s Pos[0] set from entity @a[limit=1] Pos[0]
execute as @e[tag=void_walker_clone] at @s run data modify entity @s Pos[2] set from entity @a[limit=1] Pos[2]

# ========================================
# SECTION 14: SCHEDULED EVENTS
# ========================================

# Schedule various effects
execute as @a at @s run schedule function siimpalone:myths/void_walker_phase2 4s
execute as @a at @s run schedule function siimpalone:myths/void_walker_phase3 7s

# ========================================
# SECTION 15: FINAL CLEANUP
# ========================================

# Schedule despawn
execute as @e[tag=void_walker] run schedule function siimpalone:myths/void_walker_despawn 10s
execute as @e[tag=void_walker_clone] run schedule function siimpalone:myths/void_walker_despawn 10s

# Scoreboard increase for tracking
scoreboard players add @a siimpalone_fear 3

# Additional horror effects
execute as @a at @s run title @s title {"text":"","color":"black"}
execute as @a at @s run title @s subtitle {"text":"Бездна приближается...","color":"#1a1a2e","italic":true}
execute as @a at @s run title @s times 0 20 5
