# SiimpAlone - Void Walker Despawn
# Удаление Void Walker

# Удаление сущности
kill @e[tag=void_walker]

# Звук исчезновения
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.5 0.3
