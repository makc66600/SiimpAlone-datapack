# ============================================================
# VOID WALKER - Message 3
# Третье сообщение
# ============================================================

execute as @a at @s run tellraw @s {"text":"[Void Walker]: Бесполезно сопротивляться...","color":"#4a4e69","italic":true}
execute as @a at @s run playsound minecraft:entity.skeleton.ambient master @s ~ ~ ~ 0.2 0.2
execute as @a at @s run effect give @s minecraft:nausea 2 0 true
