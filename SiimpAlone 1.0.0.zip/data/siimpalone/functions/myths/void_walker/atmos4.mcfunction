# ============================================================
# VOID WALKER - Atmosphere 4
# Атмосфера 4
# ============================================================

execute as @a at @s run particle minecraft:smoke ^ ^ ^5 1.5 1.5 1.5 0.15 8
execute as @a at @s run particle minecraft:portal ^ ^ ^2 0.5 0.5 0.5 0.08 6
execute as @a at @s run particle minecraft:shadow ^ ^ ^5 0.7 0.7 0.7 0.08 6
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 0.15 0.3
execute as @a at @s run effect give @s minecraft:darkness 4 0 true
