# ============================================================
# VOID WALKER - Move 3
# Третье перемещение - атака
# ============================================================

# Move main entity to player
execute as @e[tag=void_walker] at @p run teleport @s ^ ^ ^0.5
execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^ ^ ^ 0.3 0.3 0.3 0.05 2 force

# Move clones close
execute as @e[tag=void_walker_clone1] at @p run teleport @s ^1.5 ^ ^0
execute as @e[tag=void_walker_clone2] at @p run teleport @s ^-1.5 ^ ^0
execute as @e[tag=void_walker_clone3] at @p run teleport @s ^0 ^ ^1.5
execute as @e[tag=void_walker_clone4] at @p run teleport @s ^0 ^ ^-1.5

# Attack particles
execute as @e[tag=void_walker] at @s run particle minecraft:dragon_breath ^ ^ ^0.5 0.3 0.3 0.3 0.05 4 force
execute as @e[tag=void_walker] at @s run particle minecraft:enchant ^ ^ ^0.3 0.2 0.2 0.03 3

# Sound
execute as @a at @s run playsound minecraft:entity.wither.ambient master @s ~ ~ ~ 0.2 0.1

# Damage player
execute as @a at @s run damage @s 1 minecraft:void

# Player effects
execute as @a at @s run effect give @s minecraft:blindness 2 0 true
execute as @a at @s run effect give @s minecraft:nausea 2 0 true
