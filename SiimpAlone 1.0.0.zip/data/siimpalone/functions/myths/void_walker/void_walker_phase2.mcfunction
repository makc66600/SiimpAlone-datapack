# Void Walker Phase 2 - More intense effects
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^2 1 1 1 0.2 15 force
execute as @e[tag=void_walker] at @s run particle minecraft:soul_fire_flame ^ ^ ^1 0.5 0.5 0.5 0.05 10 force
execute as @a at @s run effect give @s minecraft:wither 3 1 true
execute as @a at @s run effect give @s minecraft:darkness 3 0 true
