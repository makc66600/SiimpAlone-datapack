# ============================================================
# VOID WALKER - Message 7
# Седьмое сообщение - финальное
# ============================================================

execute as @a at @s run tellraw @s {"text":"[Void Walker]: Беги, пока можешь...","color":"#4a4e69","italic":true,"bold":true}
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.3 0.08
execute as @a at @s run effect give @s minecraft:blindness 3 0 true
execute as @a at @s run effect give @s minecraft:wither 3 0 true
