# Void Walker Message 2
execute as @a at @s run tellraw @s {"text":"[Void Walker]: Погружайся в вечность...","color":"#4a4e69","italic":true}
execute as @a at @s run playsound minecraft:entity.wither.ambient master @s ~ ~ ~ 0.3 0.2
