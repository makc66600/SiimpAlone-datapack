# ============================================================
# VOID WALKER - Message 4
# Четвёртое сообщение
# ============================================================

execute as @a at @s run tellraw @s {"text":"[Void Walker]: Я здесь повсюду...","color":"#4a4e69","italic":true}
execute as @a at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.2 0.1
execute as @a at @s run effect give @s minecraft:blindness 2 0 true
