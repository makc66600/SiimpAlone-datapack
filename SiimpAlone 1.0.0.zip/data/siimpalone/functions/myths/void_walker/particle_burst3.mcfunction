# ============================================================
# VOID WALKER - Particle Burst 3
# Третий взрыв частиц
# ============================================================

execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^ ^ ^ 0.6 0.6 0.6 0.08 4 force
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^3 1 1 1 0.15 10 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^ ^2 0.6 0.6 0.6 0.1 8
