# ============================================================
# VOID WALKER - Message 5
# Пятое сообщение
# ============================================================

execute as @a at @s run tellraw @s {"text":"[Void Walker]: Твоя душа принадлежит тьме...","color":"#4a4e69","italic":true}
execute as @a at @s run playsound minecraft:entity.zombie.death master @s ~ ~ ~ 0.2 0.1
execute as @a at @s run effect give @s minecraft:wither 2 0 true
