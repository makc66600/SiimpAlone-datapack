# ============================================================
# VOID WALKER - Despawn
# Удаление сущности
# ============================================================

# Remove main entity
kill @e[tag=void_walker]

# Remove clones
kill @e[tag=void_walker_clone1]
kill @e[tag=void_walker_clone2]

# Final particle effect
execute as @a at @s run particle minecraft:portal ^ ^ ^3 1 1 1 0.1 10 force

# Final sound
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.3 0.1

# Message
execute as @a at @s run tellraw @s {"text":"[Void Walker]: Мы ещё встретимся...","color":"#1a1a2e","italic":true}
