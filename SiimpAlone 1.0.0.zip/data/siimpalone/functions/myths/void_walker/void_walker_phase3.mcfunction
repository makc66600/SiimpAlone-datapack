# Void Walker Phase 3 - Final intense effects
execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^ ^ ^ 1 1 1 0.1 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:large_smoke ^ ^ ^ 0.5 0.5 0.5 0.1 10 force
execute as @a at @s run effect give @s minecraft:blindness 2 0 true
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.4 0.05
