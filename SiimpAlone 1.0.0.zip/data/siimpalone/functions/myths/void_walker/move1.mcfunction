# ============================================================
# VOID WALKER - Move 1
# Первое перемещение - приближение
# ============================================================

# Move main entity closer
execute as @e[tag=void_walker] at @p run teleport @s ^ ^ ^1.5
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^0.5 0.5 0.5 0.1 5 force

# Move clones
execute as @e[tag=void_walker_clone1] at @e[tag=void_walker] run teleport @s ^1 ^ ^0.5
execute as @e[tag=void_walker_clone2] at @e[tag=void_walker] run teleport @s ^-1 ^ ^0.5
execute as @e[tag=void_walker_clone3] at @e[tag=void_walker] run teleport @s ^0.5 ^ ^1
execute as @e[tag=void_walker_clone4] at @e[tag=void_walker] run teleport @s ^-0.5 ^ ^1

# Clone particles
execute as @e[tag=void_walker_clone1] at @s run particle minecraft:shadow ^ ^ ^0.2 0.2 0.2 0.02 4 force
execute as @e[tag=void_walker_clone2] at @s run particle minecraft:shadow ^ ^ ^0.2 0.2 0.2 0.02 4 force
execute as @e[tag=void_walker_clone3] at @s run particle minecraft:shadow ^ ^ ^0.2 0.2 0.2 0.02 4 force
execute as @e[tag=void_walker_clone4] at @s run particle minecraft:shadow ^ ^ ^0.2 0.2 0.2 0.02 4 force

# Sound effect
execute as @a at @s run playsound minecraft:block.nether_portal.trigger master @s ~ ~ ~ 0.1 0.3

# Player effect
execute as @a at @s run effect give @s minecraft:darkness 2 0 true
