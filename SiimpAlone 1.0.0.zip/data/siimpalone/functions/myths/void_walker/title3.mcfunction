# ============================================================
# VOID WALKER - Title 3 (Final)
# Финальный заголовок
# ============================================================

execute as @a at @s run title @s title {"text":"","color":"black"}
execute as @a at @s run title @s subtitle {"text":"Беги!","color":"#4a4e69","italic":true,"bold":true}
execute as @a at @s run title @s times 0 20 5
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.3 0.1
