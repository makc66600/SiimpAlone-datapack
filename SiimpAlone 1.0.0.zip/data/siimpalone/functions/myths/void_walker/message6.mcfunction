# ============================================================
# VOID WALKER - Message 6
# Шестое сообщение
# ============================================================

execute as @a at @s run tellraw @s {"text":"[Void Walker]: Твой страх питает меня...","color":"#4a4e69","italic":true}
execute as @a at @s run playsound minecraft:entity.wither.ambient master @s ~ ~ ~ 0.15 0.1
execute as @a at @s run effect give @s minecraft:darkness 3 0 true
