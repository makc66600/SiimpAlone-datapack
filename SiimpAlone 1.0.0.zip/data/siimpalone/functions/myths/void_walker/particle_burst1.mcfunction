# ============================================================
# VOID WALKER - Particle Burst 1
# Первый взрыв частиц
# ============================================================

execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^1 0.5 0.5 0.5 0.06 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^ ^0.5 0.3 0.3 0.03 4
