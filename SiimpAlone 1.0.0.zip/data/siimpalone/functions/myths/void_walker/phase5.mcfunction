# ============================================================
# VOID WALKER - Phase 5 (Final)
# Фаза 5 - финальная кульминация
# ============================================================

# Ultimate particle storm
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^5 1.5 1.5 1.5 0.3 25 force
execute as @e[tag=void_walker] at @s run particle minecraft:smoke ^ ^ ^3 1 1 1 0.15 15

# Massive explosion
execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^ ^ ^ 1 1 1 0.1 8 force
execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^1 ^ ^ 0.8 0.8 0.8 0.08 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^-1 ^ ^ 0.8 0.8 0.8 0.08 5 force

# Dragon breath storm
execute as @e[tag=void_walker] at @s run particle minecraft:dragon_breath ^ ^ ^2 0.6 0.6 0.6 0.1 10 force

# All clones intense
execute as @e[tag=void_walker_clone1] at @s run particle minecraft:portal ^ ^ ^1 0.8 0.8 0.8 0.15 10 force
execute as @e[tag=void_walker_clone2] at @s run particle minecraft:portal ^ ^ ^1 0.8 0.8 0.8 0.15 10 force
execute as @e[tag=void_walker_clone3] at @s run particle minecraft:portal ^ ^ ^1 0.8 0.8 0.8 0.15 10 force
execute as @e[tag=void_walker_clone4] at @s run particle minecraft:portal ^ ^ ^1 0.8 0.8 0.8 0.15 10 force

# Final sounds
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.5 0.05
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.5 0.03

# Devastating player effects
execute as @a at @s run effect give @s minecraft:blindness 5 0 true
execute as @a at @s run effect give @s minecraft:wither 5 0 true
execute as @a at @s run effect give @s minecraft:darkness 10 0 true
execute as @a at @s run effect give @s minecraft:slowness 5 2 true
execute as @a at @s run effect give @s minecraft:nausea 5 0 true

# Heavy damage
execute as @a at @s run damage @s 3 minecraft:void
