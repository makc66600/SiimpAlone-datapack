# ============================================================
# VOID WALKER - Phase 4
# Фаза 4 - максимальная угроза
# ============================================================

# Maximum portal particles
execute as @e[tag=void_walker] at @s run particle minecraft:portal ^ ^ ^4 1.2 1.2 1.2 0.25 20 force

# Multiple explosion particles
execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^ ^ ^ 0.8 0.8 0.8 0.08 5 force
execute as @e[tag=void_walker] at @s run particle minecraft:explosion_emitter ^1 ^ ^ 0.5 0.5 0.5 0.05 3 force

# Dragon breath intense
execute as @e[tag=void_walker] at @s run particle minecraft:dragon_breath ^ ^ ^1.5 0.5 0.5 0.08 8 force

# All clones particles
execute as @e[tag=void_walker_clone1] at @s run particle minecraft:portal ^ ^ ^0.5 0.5 0.5 0.1 6 force
execute as @e[tag=void_walker_clone2] at @s run particle minecraft:portal ^ ^ ^0.5 0.5 0.5 0.1 6 force
execute as @e[tag=void_walker_clone3] at @s run particle minecraft:portal ^ ^ ^0.5 0.5 0.5 0.1 6 force
execute as @e[tag=void_walker_clone4] at @s run particle minecraft:portal ^ ^ ^0.5 0.5 0.5 0.1 6 force

# Sound effects
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.4 0.1
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.3 0.05

# Strong player effects
execute as @a at @s run effect give @s minecraft:blindness 4 0 true
execute as @a at @s run effect give @s minecraft:wither 4 0 true
execute as @a at @s run effect give @s minecraft:darkness 5 0 true
execute as @a at @s run effect give @s minecraft:slowness 4 1 true

# Damage
execute as @a at @s run damage @s 2 minecraft:void
