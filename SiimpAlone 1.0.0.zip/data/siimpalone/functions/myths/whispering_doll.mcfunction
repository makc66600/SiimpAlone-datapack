# ============================================================
# WHISPERING DOLL - Миф #11
# Шёпчущая кукла
# ============================================================

# Spawn check
execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 11

# Particle effect
execute as @a[scores={myth_id=11}] at @s run particle minecraft:crit ^ ^ ^3 0.5 0.5 0.5 0.05 5

# Sound
execute as @a[scores={myth_id=11}] at @s run playsound minecraft:entity.item.pickup master @s ~ ~ ~ 0.2 0.5

# Message
execute as @a[scores={myth_id=11}] at @s run tellraw @s {"text":"[Кукла]: Ты слышал шёпот?","color":"#ff6b6b","italic":true}
