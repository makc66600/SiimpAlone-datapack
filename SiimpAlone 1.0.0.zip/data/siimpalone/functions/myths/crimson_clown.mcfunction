# ============================================================
# CRIMSON CLOWN - Миф #20
# Багровый Клоун
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 20

execute as @a[scores={myth_id=20}] at @s run particle minecraft:happy_villager ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=20}] at @s run playsound minecraft:entity.clownfish.splash master @s ~ ~ ~ 0.2 0.5
execute as @a[scores={myth_id=20}] at @s run tellraw @s {"text":"[Клоун]: Хочешь поиграть?","color":"#ff4757","italic":true}
