# ============================================================
# BLEEDING WALL - Миф #23
# Кровоточащая Стена
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 23

execute as @a[scores={myth_id=23}] at @s run particle minecraft:drippinglava ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=23}] at @s run playsound minecraft:block.honey_block.slide master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=23}] at @s run tellraw @s {"text":"[Стена]: Помоги мне...","color":"#c0392b","italic":true}
