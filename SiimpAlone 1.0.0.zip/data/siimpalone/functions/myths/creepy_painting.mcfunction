# ============================================================
# CREEPY PAINTING - Миф #30
# Жуткая Картина
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 30

execute as @a[scores={myth_id=30}] at @s run particle minecraft:painting ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=30}] at @s run playsound minecraft:entity.painting.break master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=30}] at @s run tellraw @s {"text":"[Картина]: Не смотри...","color":"#4a235a","italic":true}
