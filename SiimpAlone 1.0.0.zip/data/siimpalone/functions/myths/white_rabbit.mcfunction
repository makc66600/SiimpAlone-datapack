# ============================================================
# WHITE RABBIT - Миф #29
# Белый Кролик
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 29

execute as @a[scores={myth_id=29}] at @s run particle minecraft:cloud ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=29}] at @s run playsound minecraft:entity.rabbit.ambient master @s ~ ~ ~ 0.2 0.5
execute as @a[scores={myth_id=29}] at @s run tellraw @s {"text":"[Кролик]: Беги!","color":"#ffffff","italic":true}
