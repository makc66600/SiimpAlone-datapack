# ============================================================
# SPECTRAL DOOR - Миф #24
# Призрачная Дверь
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 24

execute as @a[scores={myth_id=24}] at @s run particle minecraft:portal ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=24}] at @s run playsound minecraft:block.wooden_door.open master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=24}] at @s run tellraw @s {"text":"[Дверь]: Открой меня...","color":"#5d6d7e","italic":true}
