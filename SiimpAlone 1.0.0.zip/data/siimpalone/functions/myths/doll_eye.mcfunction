# ============================================================
# DOLL EYE - Миф #38
# Глаз Куклы
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 38

execute as @a[scores={myth_id=38}] at @s run particle minecraft:eye_of_villager ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=38}] at @s run playsound minecraft:entity.villager.death master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=38}] at @s run tellraw @s {"text":"[Глаз]: Не отводи взгляд...","color":"#2ecc71","italic":true}
