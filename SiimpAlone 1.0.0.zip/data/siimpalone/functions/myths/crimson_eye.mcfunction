# ============================================================
# CRIMSON EYE - Миф #13
# Багровый Глаз
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 13

execute as @a[scores={myth_id=13}] at @s run particle minecraft:eye_of_ender ^ ^ ^3 0.6 0.6 0.6 0.05 5
execute as @a[scores={myth_id=13}] at @s run playsound minecraft:entity.ender_eye.death master @s ~ ~ ~ 0.2 0.5
execute as @a[scores={myth_id=13}] at @s run tellraw @s {"text":"[Глаз]: Не отводи взгляд...","color":"#ff0000","italic":true}
