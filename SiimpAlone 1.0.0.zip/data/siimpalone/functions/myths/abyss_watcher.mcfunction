# ============================================================
# ABYSS WATCHER - Миф #17
# Наблюдатель Бездны
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 17

execute as @a[scores={myth_id=17}] at @s run particle minecraft:deep_dark ^ ^ ^3 0.5 0.5 0.5 0.06 5
execute as @a[scores={myth_id=17}] at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.2 0.1
execute as @a[scores={myth_id=17}] at @s run tellraw @s {"text":"[Наблюдатель]: Бездна смотрит в ответ...","color":"#2d1b4e","italic":true}
