# ============================================================
# ANGRY TOY - Миф #34
# Злая Игрушка
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 34

execute as @a[scores={myth_id=34}] at @s run particle minecraft:angry_villager ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=34}] at @s run playsound minecraft:entity.villager.angry master @s ~ ~ ~ 0.2 0.5
execute as @a[scores={myth_id=34}] at @s run tellraw @s {"text":"[Игрушка]: Я тебя вижу!","color":"#e74c3c","italic":true}
