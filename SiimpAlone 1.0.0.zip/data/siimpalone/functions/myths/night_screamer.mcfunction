# ============================================================
# NIGHT SCREAMER - Миф #39
# Ночной Крикун
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 39

execute as @a[scores={myth_id=39}] at @s run particle minecraft:screaming ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=39}] at @s run playsound minecraft:entity.phantom.scream master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=39}] at @s run tellraw @s {"text":"[Крик]: АААААА!","color":"#c0392b","italic":true}
