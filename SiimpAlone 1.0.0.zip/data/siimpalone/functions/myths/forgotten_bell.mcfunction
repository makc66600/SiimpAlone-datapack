# ============================================================
# FORGOTTEN BELL - Миф #19
# Забытый Колокол
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 19

execute as @a[scores={myth_id=19}] at @s run particle minecraft:note ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=19}] at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 0.2 0.5
execute as @a[scores={myth_id=19}] at @s run tellraw @s {"text":"[Колокол]: Звон... забытый временем...","color":"#ffd700","italic":true}
