# SiimpAlone - Night Phantom Despawn
# Удаление Night Phantom

# Удаление сущности
kill @e[tag=night_phantom]

# Звук исчезновения
execute as @a at @s run playsound minecraft:entity.phantom.flap master @s ~ ~ ~ 0.5 0.4
