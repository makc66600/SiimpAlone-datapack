# SiimpAlone - NIGHT PHANTOM (Улучшенный)
# Ночной Фантом - призрак ночи

# Спавн с эффектом
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^6 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:0b,CustomName:'{"text":"Night Phantom","color":"#9b59b6","bold":true,"italic":false}',CustomNameVisible:1b,Tags:["siimpalone_myth","night_phantom"],ArmorItems:[{},{},{},{id:"minecraft:purple_wool",Count:1b}],Pose:{Head:[-20f,0f,0f]}}

# Частицы призрака
execute as @e[tag=night_phantom] at @s run particle minecraft:witch ^ ^ ^1 0.5 0.5 0.5 0.1 10 force
execute as @e[tag=night_phantom] at @s run particle minecraft:soul ^ ^ ^0.5 0.3 0.3 0.3 0.05 8

# Жуткий звук
execute as @a at @s run playsound minecraft:entity.phantom.death master @s ~ ~ ~ 0.6 0.3
execute as @a at @s run playsound minecraft:ambient.soul_forest.valley master @s ~ ~ ~ 0.4 0.2

# Эффекты на игрока
execute as @a at @s run effect give @s minecraft:wither 5 1 true
execute as @a at @s run effect give @s minecraft:darkness 3 0 true
execute as @a at @s run effect give @s minecraft:levitation 2 0 true

# Телепортация
execute as @a at @s run teleport @e[tag=night_phantom] ~ ~3 ~

# Сообщение
execute as @a at @s run tellraw @s {"text":"[Night Phantom]: Ночь принадлежит мне...","color":"#8e44ad","italic":true}

# Удаление через время
execute as @e[tag=night_phantom] run schedule function siimpalone:myths/night_phantom_despawn 12s
