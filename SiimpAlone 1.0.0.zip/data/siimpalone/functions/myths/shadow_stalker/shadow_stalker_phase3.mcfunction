# Shadow Stalker Phase 3
execute as @e[tag=shadow_stalker] at @s run particle minecraft:explosion_emitter ^ ^ ^ 0.5 0.5 0.5 0.05 3 force
execute as @e[tag=shadow_stalker] at @s run particle minecraft:large_smoke ^ ^ ^ 0.3 0.3 0.3 0.05 5
execute as @a at @s run effect give @s minecraft:wither 2 0 true
execute as @a at @s run playsound minecraft:entity.zombie.break_wooden_door master @s ~ ~ ~ 0.2 0.2
