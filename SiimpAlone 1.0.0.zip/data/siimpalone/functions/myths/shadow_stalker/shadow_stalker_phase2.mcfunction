# Shadow Stalker Phase 2
execute as @e[tag=shadow_stalker] at @s run particle minecraft:shadow ^ ^ ^2 0.5 0.5 0.5 0.08 10 force
execute as @e[tag=shadow_stalker] at @s run particle minecraft:witch ^ ^ ^1 0.3 0.3 0.3 0.05 8 force
execute as @a at @s run effect give @s minecraft:darkness 3 0 true
execute as @a at @s run effect give @s minecraft:blindness 2 0 true
