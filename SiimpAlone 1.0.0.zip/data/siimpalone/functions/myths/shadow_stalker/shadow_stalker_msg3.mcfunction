# Shadow Stalker Message 3
execute as @a at @s run tellraw @s {"text":"[Shadow Stalker]: Бесполезно убегать...","color":"#6c757d","italic":true}
execute as @a at @s run playsound minecraft:entity.skeleton.ambient master @s ~ ~ ~ 0.2 0.3
