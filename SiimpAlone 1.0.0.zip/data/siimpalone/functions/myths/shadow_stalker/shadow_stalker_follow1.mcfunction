# Shadow Stalker Follow 1
execute as @e[tag=shadow_stalker] at @p run teleport @s ^ ^ ^1.5
execute as @e[tag=shadow_stalker] at @s run particle minecraft:shadow ^ ^ ^0.2 0.2 0.2 0.2 0.03 4 force
