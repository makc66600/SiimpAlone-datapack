# Shadow Stalker Follow 3
execute as @e[tag=shadow_stalker] at @p run teleport @s ^-0.5 ^ ^1
execute as @e[tag=shadow_clone2] at @p run teleport @s ^0.3 ^ ^1.5
execute as @e[tag=shadow_stalker] at @s run particle minecraft:soul ^ ^ ^0.2 0.2 0.2 0.2 0.03 4 force
