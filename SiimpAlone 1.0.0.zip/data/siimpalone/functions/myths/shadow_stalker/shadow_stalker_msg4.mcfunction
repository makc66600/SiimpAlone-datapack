# Shadow Stalker Message 4
execute as @a at @s run tellraw @s {"text":"[Shadow Stalker]: Я уже здесь...","color":"#6c757d","italic":true}
execute as @a at @s run playsound minecraft:entity.zombie.death master @s ~ ~ ~ 0.2 0.1
