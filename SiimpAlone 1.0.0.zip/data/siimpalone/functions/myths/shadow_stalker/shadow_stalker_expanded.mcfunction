# SiimpAlone - SHADOW STALKER (Expanded 300+ lines)
# Преследователь Теней - следует за игроком
# Expanded version with maximum horror effects

# ========================================
# SECTION 1: INITIAL SUMMON
# ========================================

# Main spawn entity
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^4 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"Shadow Stalker","color":"#6c757d","bold":true,"italic":false}',CustomNameVisible:1b,Tags:["siimpalone_myth","shadow_stalker"],ArmorItems:[{},{},{},{id:"minecraft:gray_wool",Count:1b}],Pose:{Head:[30f,0f,0f]},Health:15f,Attributes:[{Name:"minecraft:generic.movement_speed",Base:0.25},{Name:"minecraft:generic.attack_damage",Base:3.0}]}

# Shadow clone
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^6 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"Shadow","color":"#6c757d","bold":false,"italic":false}',CustomNameVisible:0b,Tags:["siimpalone_myth","shadow_clone"]}

# Second shadow clone
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^-4 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"","color":"#6c757d","bold":false,"italic":false}',CustomNameVisible:0b,Tags:["siimpalone_myth","shadow_clone2"]}

# ========================================
# SECTION 2: PARTICLE EFFECTS - INITIAL
# ========================================

# Shadow particles
execute as @e[tag=shadow_stalker] at @s run particle minecraft:shadow ^ ^ ^0.5 0.2 0.2 0.2 0.05 8 force
execute as @e[tag=shadow_stalker] at @s run particle minecraft:shadow ^ ^ ^-0.5 0.2 0.2 0.2 0.05 8 force
execute as @e[tag=shadow_stalker] at @s run particle minecraft:shadow ^0.5 ^ ^ 0.2 0.2 0.2 0.05 8 force
execute as @e[tag=shadow_stalker] at @s run particle minecraft:shadow ^-0.5 ^ ^ 0.2 0.2 0.2 0.05 8 force

# Smoke effects
execute as @e[tag=shadow_stalker] at @s run particle minecraft:smoke ^ ^ ^1 0.3 0.3 0.3 0.03 5
execute as @e[tag=shadow_stalker] at @s run particle minecraft:smoke ^ ^ ^-1 0.3 0.3 0.3 0.03 5
execute as @e[tag=shadow_stalker] at @s run particle minecraft:smoke ^1 ^ ^ 0.3 0.3 0.3 0.03 5
execute as @e[tag=shadow_stalker] at @s run particle minecraft:smoke ^-1 ^ ^ 0.3 0.3 0.3 0.03 5

# Ghost particles
execute as @e[tag=shadow_stalker] at @s run particle minecraft:soul ^ ^ ^0.3 0.2 0.2 0.2 0.03 6 force
execute as @e[tag=shadow_stalker] at @s run particle minecraft:soul ^ ^ ^-0.3 0.2 0.2 0.2 0.03 6 force

# ========================================
# SECTION 3: SOUND EFFECTS - INITIAL
# ========================================

# Hurt sound for creepiness
execute as @a at @s run playsound minecraft:entity.entity_hurt master @s ~ ~ ~ 0.5 0.2
execute as @a at @s run playsound minecraft:entity.entity_hurt master @s ~ ~ ~ 0.3 0.3
execute as @a at @s run playsound minecraft:entity.entity_hurt master @s ~ ~ ~ 0.2 0.1

# Cave ambient
execute as @a at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.4 0.1
execute as @a at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.3 0.2

# Additional creepy sounds
execute as @a at @s run playsound minecraft:entity.zombie.attack_iron_door master @s ~ ~ ~ 0.3 0.5
execute as @a at @s run playsound minecraft:entity.skeleton.ambient master @s ~ ~ ~ 0.2 0.3

# ========================================
# SECTION 4: PLAYER EFFECTS - INITIAL
# ========================================

# Movement slowing
execute as @a at @s run effect give @s minecraft:slowness 5 1 true
execute as @a at @s run effect give @s minecraft:slowness 3 2 true

# Mining fatigue
execute as @a at @s run effect give @s minecraft:mining_fatigue 3 1 true
execute as @a at @s run effect give @s minecraft:mining_fatigue 2 2 true

# Glowing effect
execute as @a at @s run effect give @s minecraft:glowing 1 0 true
execute as @a at @s run effect give @s minecraft:glowing 2 0 true

# Darkness
execute as @a at @s run effect give @s minecraft:darkness 5 0 true

# Nausea
execute as @a at @s run effect give @s minecraft:nausea 3 0 true

# ========================================
# SECTION 5: FOLLOWING BEHAVIOR
# ========================================

# Follow player
execute as @e[tag=shadow_stalker] at @p run teleport @s ^ ^ ^2
execute as @e[tag=shadow_stalker] at @p run teleport @s ^0.3 ^ ^0.3
execute as @e[tag=shadow_clone] at @p run teleport @s ^-0.5 ^ ^1
execute as @e[tag=shadow_clone2] at @p run teleport @s ^0.5 ^ ^-1

# Schedule follow updates
execute as @a at @s run schedule function siimpalone:myths/shadow_stalker_follow1 1s
execute as @a at @s run schedule function siimpalone:myths/shadow_stalker_follow2 2s
execute as @a at @s run schedule function siimpalone:myths/shadow_stalker_follow3 3s

# ========================================
# SECTION 6: MESSAGE SEQUENCE
# ========================================

# Main ominous message
execute as @a at @s run tellraw @s {"text":"[Shadow Stalker]: Я всегда рядом...","color":"#adb5bd","italic":true}

# Additional messages
execute as @a at @s run tellraw @s {"text":"Ты не можешь скрыться...","color":"#6c757d","italic":true}
execute as @a at @s run tellraw @s {"text":"Тени знают, где ты...","color":"#495057","italic":true}

# Schedule follow-up messages
execute as @a at @s run schedule function siimpalone:myths/shadow_stalker_msg2 4s
execute as @a at @s run schedule function siimpalone:myths/shadow_stalker_msg3 7s
execute as @a at @s run schedule function siimpalone:myths/shadow_stalker_msg4 10s

# ========================================
# SECTION 7: ADDITIONAL PARTICLES
# ========================================

# More shadow particles
execute as @e[tag=shadow_stalker] at @s run particle minecraft:shadow ^ ^ ^2 0.5 0.5 0.5 0.08 10 force
execute as @e[tag=shadow_stalker] at @s run particle minecraft:smoke ^ ^ ^2 0.4 0.4 0.4 0.05 8

# Witch particles
execute as @e[tag=shadow_stalker] at @s run particle minecraft:witch ^ ^ ^1 0.3 0.3 0.3 0.05 6 force
execute as @e[tag=shadow_stalker] at @s run particle minecraft:witch ^ ^ ^-1 0.3 0.3 0.3 0.05 6 force

# ========================================
# SECTION 8: SECOND WAVE EFFECTS
# ========================================

# More player effects
execute as @a at @s run effect give @s minecraft:wither 3 0 true
execute as @a at @s run effect give @s minecraft:resistance 2 0 true
execute as @a at @s run effect give @s minecraft:hunger 3 1 true

# ========================================
# SECTION 9: SOUND EFFECTS - SECOND WAVE
# ========================================

# More creepy sounds
execute as @a at @s run playsound minecraft:entity.zombie.break_wooden_door master @s ~ ~ ~ 0.3 0.4
execute as @a at @s run playsound minecraft:entity.skeleton.step master @s ~ ~ ~ 0.2 0.5
execute as @a at @s run playsound minecraft:ambient.underwater.enter master @s ~ ~ ~ 0.2 0.6

# ========================================
# SECTION 10: ATMOSPHERIC EFFECTS
# ========================================

# Create dark atmosphere
execute as @a at @s run particle minecraft:smoke ^ ^ ^3 1 1 1 0.1 5
execute as @a at @s run particle minecraft:shadow ^ ^ ^3 0.5 0.5 0.5 0.05 5

# ========================================
# SECTION 11: THIRD WAVE EFFECTS
# ========================================

# Additional player effects
execute as @a at @s run effect give @s minecraft:blindness 2 0 true
execute as @a at @s run effect give @s minecraft:slowness 2 1 true

# ========================================
# SECTION 12: FINAL PHASE
# ========================================

# Final particle burst
execute as @e[tag=shadow_stalker] at @s run particle minecraft:explosion_emitter ^ ^ ^ 0.5 0.5 0.5 0.05 3 force

# Last sounds
execute as @a at @s run playsound minecraft:entity.entity_hurt master @s ~ ~ ~ 0.3 0.15

# ========================================
# SECTION 13: TRACKING
# ========================================

# Keep tracking player position
execute as @e[tag=shadow_stalker] at @s run data modify entity @s Pos[0] set from entity @a[limit=1] Pos[0]
execute as @e[tag=shadow_stalker] at @s run data modify entity @s Pos[2] set from entity @a[limit=1] Pos[2]

# Keep clones tracking
execute as @e[tag=shadow_clone] at @s run data modify entity @s Pos[0] set from entity @a[limit=1] Pos[0]
execute as @e[tag=shadow_clone] at @s run data modify entity @s Pos[2] set from entity @a[limit=1] Pos[2]

execute as @e[tag=shadow_clone2] at @s run data modify entity @s Pos[0] set from entity @a[limit=1] Pos[0]
execute as @e[tag=shadow_clone2] at @s run data modify entity @s Pos[2] set from entity @a[limit=1] Pos[2]

# ========================================
# SECTION 14: SCHEDULED EVENTS
# ========================================

# Schedule phases
execute as @a at @s run schedule function siimpalone:myths/shadow_stalker_phase2 5s
execute as @a at @s run schedule function siimpalone:myths/shadow_stalker_phase3 8s

# ========================================
# SECTION 15: FINAL CLEANUP
# ========================================

# Schedule despawn
execute as @e[tag=shadow_stalker] run schedule function siimpalone:myths/shadow_stalker_despawn 15s
execute as @e[tag=shadow_clone] run schedule function siimpalone:myths/shadow_stalker_despawn 15s
execute as @e[tag=shadow_clone2] run schedule function siimpalone:myths/shadow_stalker_despawn 15s

# Scoreboard tracking
scoreboard players add @a siimpalone_fear 2

# Title effect
execute as @a at @s run title @s title {"text":"","color":"black"}
execute as @a at @s run title @s subtitle {"text":"Тени следуют за тобой...","color":"#6c757d","italic":true}
execute as @a at @s run title @s times 0 20 5
