# SiimpAlone - SHADOW STALKER (Улучшенный)
# Преследователь Теней - следует за игроком

# Спавн с эффектом тени
execute as @a at @s run summon minecraft:armor_stand ^ ^ ^4 {NoGravity:1b,Invisible:1b,Invulnerable:1b,Small:1b,CustomName:'{"text":"Shadow Stalker","color":"#6c757d","bold":true,"italic":false}',CustomNameVisible:1b,Tags:["siimpalone_myth","shadow_stalker"],ArmorItems:[{},{},{},{id:"minecraft:gray_wool",Count:1b}],Pose:{Head:[30f,0f,0f]}}

# Частицы тени
execute as @e[tag=shadow_stalker] at @s run particle minecraft:shadow ^ ^ ^0.5 0.2 0.2 0.2 0.05 8 force
execute as @e[tag=shadow_stalker] at @s run particle minecraft:smoke ^ ^ ^1 0.3 0.3 0.3 0.03 5

# Жуткий звук
execute as @a at @s run playsound minecraft:entity.entity_hurt master @s ~ ~ ~ 0.5 0.2
execute as @a at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.4 0.1

# Эффекты на игрока
execute as @a at @s run effect give @s minecraft:slowness 5 1 true
execute as @a at @s run effect give @s minecraft:mining_fatigue 3 1 true
execute as @a at @s run effect give @s minecraft:glowing 1 0 true

# Следование за игроком
execute as @e[tag=shadow_stalker] at @p run teleport @s ^ ^ ^2

# Жуткое сообщение
execute as @a at @s run tellraw @s {"text":"[Shadow Stalker]: Я всегда рядом...","color":"#adb5bd","italic":true}

# Удаление через время
execute as @e[tag=shadow_stalker] run schedule function siimpalone:myths/shadow_stalker_despawn 15s
