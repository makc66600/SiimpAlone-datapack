# SiimpAlone - Shadow Stalker Despawn
# Удаление Shadow Stalker

# Удаление сущности
kill @e[tag=shadow_stalker]

# Звук исчезновения
execute as @a at @s run playsound minecraft:entity.phantom.death master @s ~ ~ ~ 0.5 0.3
