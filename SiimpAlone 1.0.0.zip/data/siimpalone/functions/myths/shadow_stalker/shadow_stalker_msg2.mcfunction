# Shadow Stalker Message 2
execute as @a at @s run tellraw @s {"text":"[Shadow Stalker]: Тени знают твои шаги...","color":"#6c757d","italic":true}
execute as @a at @s run playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 0.3 0.2
