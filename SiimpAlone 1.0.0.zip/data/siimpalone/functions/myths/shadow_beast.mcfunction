# ============================================================
# SHADOW BEAST - Миф #32
# Теневая Тварь
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 32

execute as @a[scores={myth_id=32}] at @s run particle minecraft:large_smoke ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=32}] at @s run playsound minecraft:entity.wolf.growl master @s ~ ~ ~ 0.2 0.3
execute as @a[scores={myth_id=32}] at @s run tellraw @s {"text":"[Тварь]: Охота началась...","color":"#2c3e50","italic":true}
