# ============================================================
# MIRROR SHADOW - Миф #18
# Теневой Двойник
# ============================================================

execute if entity @a[tag=!myth_active] run scoreboard players set @a myth_id 18

execute as @a[scores={myth_id=18}] at @s run particle minecraft:reflection ^ ^ ^3 0.5 0.5 0.5 0.05 5
execute as @a[scores={myth_id=18}] at @s run playsound minecraft:entity.zombie.ambient master @s ~ ~ ~ 0.15 0.3
execute as @a[scores={myth_id=18}] at @s run tellraw @s {"text":"[Двойник]: Я - это ты...","color":"#4a5568","italic":true}
