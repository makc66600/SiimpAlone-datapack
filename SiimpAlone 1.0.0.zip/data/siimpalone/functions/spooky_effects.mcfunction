# SiimpAlone - Spooky Effects
# Жуткие эффекты для игроков в темноте

# Звуки жуткие
execute as @a at @s if predicate siimpalone:light_check run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.3 0.1

# Случайный звук
execute as @a at @s if predicate siimpalone:light_check if entity @a[distance=20..] run playsound minecraft:entity.generic.hurt master @s ~ ~ ~ 0.2 0.5

# Эффект затемнения (только ночью)
execute as @a at @s if predicate siimpalone:light_check if score #night_check is_night matches 1 run effect give @s minecraft:darkness 3 0 true
