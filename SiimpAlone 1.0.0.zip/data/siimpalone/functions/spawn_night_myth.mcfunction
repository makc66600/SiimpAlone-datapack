# SiimpAlone - Spawn Night Myth
# Ночной спавн с балансом - более частое появление

# Случайный выбор (1-7) - больше мифов ночью
scoreboard players set #random siimpalone_spawn 0
execute store result score #random siimpalone_spawn run random value 1..7

# Ночные мифы (высокая вероятность)
execute if score #random siimpalone_spawn matches 1 run function siimpalone:myths/void_walker
execute if score #random siimpalone_spawn matches 2 run function siimpalone:myths/shadow_stalker
execute if score #random siimpalone_spawn matches 3 run function siimpalone:myths/night_phantom

# Редкие ночные мифы
execute if score #random siimpalone_spawn matches 4 run function siimpalone:myths/revuxor
execute if score #random siimpalone_spawn matches 5 run function siimpalone:myths/anti_siimp

# Очень редкие мифы ночью
execute if score #random siimpalone_spawn matches 6 run function siimpalone:myths/voqude
execute if score #random siimpalone_spawn matches 7 run function siimpalone:myths/tentar
