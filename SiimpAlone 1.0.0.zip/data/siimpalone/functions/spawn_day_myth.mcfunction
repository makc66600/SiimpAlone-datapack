# SiimpAlone - Spawn Day Myth
# Дневной спавн с балансом - меньшая вероятность появления

# Случайный выбор (1-10) - меньше мифов днем
scoreboard players set #random siimpalone_spawn 0
execute store result score #random siimpalone_spawn run random value 1..10

# Дневные мифы (низкая вероятность)
execute if score #random siimpalone_spawn matches 1..3 if predicate siimpalone:light_check run function siimpalone:myths/tentar

# Очень редкие дневные мифы
execute if score #random siimpalone_spawn matches 4..5 if predicate siimpalone:light_check run function siimpalone:myths/voqude

# Редкий шанс днем (только в темноте)
execute if score #random siimpalone_spawn matches 6..7 if predicate siimpalone:light_check run function siimpalone:myths/shadow_stalker

# Минимальный шанс ночного мифа днем (только в полной тьме)
execute if score #random siimpalone_spawn matches 8 if predicate siimpalone:light_check run function siimpalone:myths/night_phantom

# Anti_Siimp может появиться в любое время (редко)
execute if score #random siimpalone_spawn matches 9 if predicate siimpalone:light_check run function siimpalone:myths/anti_siimp

# Сообщение о безопасности днем
execute if score #random siimpalone_spawn matches 10 run tellraw @s {"text":"Днём безопаснее... но ненадолго.","color":"gray","italic":true}
