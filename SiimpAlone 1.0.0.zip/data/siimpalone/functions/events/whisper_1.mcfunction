# Whisper 1
execute as @a at @s run playsound minecraft:ambient.soul_forest.valley master @s ~ ~ ~ 0.5 0.2
execute as @a at @s run tellraw @s {"text":"Они приближаются...","color":"#9370db","italic":true}
