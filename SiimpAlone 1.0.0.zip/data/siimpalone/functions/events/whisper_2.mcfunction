# Whisper 2
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 0.6 0.3
execute as @a at @s run tellraw @s {"text":"Не оглядывайся...","color":"#9370db","italic":true}
