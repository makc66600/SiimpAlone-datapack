# SiimpAlone - WHISPERING NIGHT EVENT
# Шёпот ночи - случайные голоса

# Установка флага
scoreboard players set #whispering_night_active siimpalone_chaos 1

# Сообщение
execute as @a at @s run tellraw @s {"text":"🌙 WHISPERING NIGHT 🌙","color":"#4b0082","bold":true}
execute as @a at @s run tellraw @s {"text":"Ты слышишь шёпот...","color":"#8a2be2","italic":true}

# Голоса (рандомные звуки)
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 0.8 0.1
execute as @a at @s run schedule function siimpalone:events/whisper_1 5s
execute as @a at @s run schedule function siimpalone:events/whisper_2 10s
execute as @a at @s run schedule function siimpalone:events/whisper_3 15s
execute as @a at @s run schedule function siimpalone:events/whisper_4 20s
execute as @a at @s run schedule function siimpalone:events/whispering_night_end 30s

# Эффект
execute as @a at @s run effect give @s minecraft:nausea 10 0 true
execute as @a at @s run effect give @s minecraft:darkness 10 0 true
