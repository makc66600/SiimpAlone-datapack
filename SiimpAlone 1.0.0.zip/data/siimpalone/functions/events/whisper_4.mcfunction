# Whisper 4
execute as @a at @s run playsound minecraft:ambient.underwater.enter master @s ~ ~ ~ 0.5 0.1
execute as @a at @s run tellraw @s {"text":"Беги...","color":"#9370db","italic":true}
