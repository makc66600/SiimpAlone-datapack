# ============================================================
# STRANGER FOOTSTEPS - Событие
# Чужие Шаги
# ============================================================

execute as @a at @s run playsound minecraft:entity.zombie.attack_iron_door master @s ~ ~ ~ 0.3 0.8
execute as @a at @s run tellraw @s {"text":"[Шаги]: Топ... топ...","color":"#95a5a6","italic":true}
schedule function siimpalone:events/stranger_footsteps 20s
