# SiimpAlone - BLOOD MOON EVENT END
# Конец события Кровавая луна

# Сброс флага
scoreboard players set #blood_moon_active siimpalone_chaos 0
scoreboard players set #spawn_multiplier siimpalone_chaos 1

# Сообщение
execute as @a at @s run tellraw @s {"text":"Кровавая луна зашла...","color":"#666666","italic":true}

# Возврат погоды
execute as @a at @s run weather clear

# Звук
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.additions master @s ~ ~ ~ 0.5 0.5
