# ============================================================
# SUDDEN DARKNESS - Событие
# Внезапная Темнота
# ============================================================

execute as @a at @s run title @s title {"text":"Темнота","color":"black","bold":true}
execute as @a at @s run title @s subtitle {"text":"Свет исчез...","color":"gray","italic":true}
execute as @a at @s run playsound minecraft:block.netherite_block.place master @s ~ ~ ~ 1 0.5
execute as @a at @s run weather thunder
