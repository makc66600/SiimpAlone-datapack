# SiimpAlone - MASS ENCOUNTER EVENT
# Массовая встреча - несколько мифов одновременно

# Установка флага
scoreboard players set #mass_encounter_active siimpalone_chaos 1

# Сообщение
execute as @a at @s run tellraw @s {"text":"⚠ MASS ENCOUNTER ⚠","color":"#ff4500","bold":true}
execute as @a at @s run tellraw @s {"text":"Они все здесь...","color":"#dc143c","italic":true}

# Спавн всех мифов
execute as @a at @s run function siimpalone:myths/void_walker
execute as @a at @s run function siimpalone:myths/shadow_stalker
execute as @a at @s run function siimpalone:myths/night_phantom

# Звуки
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 1.0 0.1
execute as @a at @s run playsound minecraft:entity.phantom.death master @s ~ ~ ~ 0.8 0.2
execute as @a at @s run playsound minecraft:entity.entity_hurt master @s ~ ~ ~ 0.6 0.3

# Эффекты
execute as @a at @s run effect give @s minecraft:blindness 5 0 true
execute as @a at @s run effect give @s minecraft:wither 5 1 true

# Продолжительность
schedule function siimpalone:events/mass_encounter_end 30s
