# SiimpAlone - BLOOD MOON EVENT
# Кровавая луна - увеличенный спавн мифов

# Изменение неба на кроваво-красный
execute as @a at @s run weather thunder
execute as @a at @s run time set 18000

# Сообщение о начале события
execute as @a at @s run tellraw @s {"text":"🌙 BLOOD MOON RISES 🌙","color":"#ff0000","bold":true,"italic":false}
execute as @a at @s run tellraw @s {"text":"Мифы становятся сильнее...","color":"#8b0000","italic":true}

# Установка флага события
scoreboard players set #blood_moon_active siimpalone_chaos 1

# Звуковые эффекты
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 1.0 0.1
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.8 0.2

# Увеличение вероятности спавна в 3 раза
scoreboard players set #spawn_multiplier siimpalone_chaos 3

# Атмосферные эффекты - красные частицы
execute as @a at @s run particle minecraft:dragon_breath ^ ^ ^5 2 2 2 0.1 20 force

# Эффект на игрока
execute as @a at @s run effect give @s minecraft:resistance 30 0 true

# Продолжительность события
schedule function siimpalone:events/blood_moon_end 120s

# Повышенный хаос
scoreboard players add @a siimpalone_chaos 5
