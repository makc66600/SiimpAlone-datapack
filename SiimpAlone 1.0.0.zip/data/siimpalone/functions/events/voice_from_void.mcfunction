# ============================================================
# VOICE FROM VOICE - Событие
# Голос из Пустоты
# ============================================================

execute as @a at @s run tellraw @s {"text":"[Голос]: Ты чувствуешь это?","color":"#2c3e50","italic":true}
execute as @a at @s run playsound minecraft:entity.ghast.scream master @s ~ ~ ~ 0.5 0.5
execute as @a at @s run particle minecraft:large_smoke ^ ^ ^10 1 1 1 0.05 10
schedule function siimpalone:events/voice_from_void 30s
