# Whisper 3
execute as @a at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 0.7 0.2
execute as @a at @s run tellraw @s {"text":"Ты не один...","color":"#9370db","italic":true}
