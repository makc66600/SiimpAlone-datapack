# SiimpAlone - WHISPERING NIGHT EVENT END
# Конец шёпота ночи

# Сброс флага
scoreboard players set #whispering_night_active siimpalone_chaos 0

# Сообщение
execute as @a at @s run tellraw @s {"text":"Шёпот стих...","color":"#666666","italic":true}
