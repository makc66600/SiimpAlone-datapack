# SiimpAlone - FALSE DAY EVENT END
# Конец ложного дня

# Сброс флага
scoreboard players set #false_day_active siimpalone_chaos 0

# Возврат времени
execute as @a at @s run time set 1000
execute as @a at @s run weather clear

# Сообщение
execute as @a at @s run tellraw @s {"text":"Солнце вернулось...","color":"#ffd700","italic":true}
