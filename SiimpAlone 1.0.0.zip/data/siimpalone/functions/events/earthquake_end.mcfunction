# SiimpAlone - EARTHQUAKE EVENT END
# Конец землетрясения

# Сброс флага
scoreboard players set #earthquake_active siimpalone_chaos 0

# Сообщение
execute as @a at @s run tellraw @s {"text":"Земля успокоилась.","color":"#666666","italic":true}

# Звук
execute as @a at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 0.5 0.5
