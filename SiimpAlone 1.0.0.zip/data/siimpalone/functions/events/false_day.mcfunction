# SiimpAlone - FALSE DAY EVENT
# Ложный день - день внезапно становится ночью

# Установка времени на ночь
execute as @a at @s run time set 18000
execute as @a at @s run weather thunder

# Сообщение
execute as @a at @s run tellraw @s {"text":"☾ FALSE DAY ☾","color":"#191970","bold":true}
execute as @a at @s run tellraw @s {"text":"Солнце исчезло...","color":"#000080","italic":true}

# Установка флага
scoreboard players set #false_day_active siimpalone_chaos 1

# Звуковые эффекты
execute as @a at @s run playsound minecraft:ambient.nether.crimson_forest.mood master @s ~ ~ ~ 1.0 0.1
execute as @a at @s run playsound minecraft:entity.phantom.death master @s ~ ~ ~ 0.8 0.3

# Частицы тьмы
execute as @a at @s run particle minecraft:witch ^ ^ ^5 2 2 2 0.1 15 force

# Эффекты на игрока
execute as @a at @s run effect give @s minecraft:darkness 10 0 true
execute as @a at @s run effect give @s minecraft:night_vision 10 0 true

# Продолжительность
schedule function siimpalone:events/false_day_end 45s
