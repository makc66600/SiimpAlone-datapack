# SiimpAlone - MASS ENCOUNTER EVENT END
# Конец массовой встречи

# Сброс флага
scoreboard players set #mass_encounter_active siimpalone_chaos 0

# Сообщение
execute as @a at @s run tellraw @s {"text":"Мифы исчезли... пока что.","color":"#666666","italic":true}

# Удаление всех мифов
kill @e[tag=siimpalone_myth]
