# ============================================================
# OMINOUS SIGN - Событие
# Зловещий Знак
# ============================================================

execute as @a at @s run title @s title {"text":"Зловещий знак","color":"dark_red","bold":true}
execute as @a at @s run title @s subtitle {"text":"Что-то приближается...","color":"red","italic":true}
execute as @a at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 1 0.5
execute as @a at @s run particle minecraft:smoke ^ ^ ^5 2 2 2 0.1 20
