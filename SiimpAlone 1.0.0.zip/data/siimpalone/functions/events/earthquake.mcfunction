# SiimpAlone - EARTHQUAKE EVENT
# Землетрясение - тряска экрана

# Установка флага
scoreboard players set #earthquake_active siimpalone_chaos 1

# Сообщение
execute as @a at @s run tellraw @s {"text":"🌋 EARTHQUAKE 🌋","color":"#8b4513","bold":true}
execute as @a at @s run tellraw @s {"text":"Земля трясется!","color":"#a0522d","italic":true}

# Звуки землетрясения
execute as @a at @s run playsound minecraft:block.stone.break master @s ~ ~ ~ 1.0 0.1
execute as @a at @s run playsound minecraft:block.basalt.break master @s ~ ~ ~ 0.8 0.2
execute as @a at @s run playsound minecraft:entity.generic.explode master @s ~ ~ ~ 0.6 0.3

# Эффекты тряски через particle (визуальная имитация)
execute as @a at @s run particle minecraft:explosion_emitter ^ ^ ^3 1 1 1 0.1 5 force
execute as @a at @s run particle minecraft:explosion_emitter ^ ^ ^-3 1 1 1 0.1 5 force
execute as @a at @s run particle minecraft:explosion_emitter ^3 ^ ^ 1 1 1 0.1 5 force
execute as @a at @s run particle minecraft:explosion_emitter ^-3 ^ ^ 1 1 1 0.1 5 force

# Эффекты на игрока
execute as @a at @s run effect give @s minecraft:slowness 5 2 true
execute as @a at @s run effect give @s minecraft:nausea 5 0 true
execute as @a at @s run effect give @s minecraft:resistance 5 1 true

# Продолжительность
schedule function siimpalone:events/earthquake_end 15s
