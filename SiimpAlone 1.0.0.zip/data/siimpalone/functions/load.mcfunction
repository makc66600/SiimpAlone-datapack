# SiimpAlone - Load Function
# Инициализация датапака SiimpAlone

# Сообщение при загрузке
tellraw @a {"text":" SiimpAlone Datapack loaded! ","color":"dark_red","bold":true}
tellraw @a {"text":"Добро пожаловать на сервер...","color":"gray","italic":true}

# Установка переменных
scoreboard objectives add siimpalone_timer dummy
scoreboard objectives add siimpalone_spawn dummy
scoreboard objectives add siimpalone_chaos dummy
scoreboard objectives add is_night dummy

# Запуск цикла
schedule function siimpalone:main_loop 1t replace
