# SiimpAlone - Main Loop
# Главный цикл

# Таймер
scoreboard players add #timer siimpalone_timer 1

# Проверка каждые 100 тиков
execute if score #timer siimpalone_timer matches 100 run function siimpalone:check_events

# Жуткие эффекты каждые 200 тиков
execute if score #timer siimpalone_timer matches 200 run function siimpalone:spooky_effects

# Попытка спавна каждые 300 тиков
execute if score #timer siimpalone_timer matches 300 run function siimpalone:try_spawn_myth

# Случайное событие каждые 400 тиков
execute if score #timer siimpalone_timer matches 400 run function siimpalone:random_event

# Сброс таймера
execute if score #timer siimpalone_timer matches 400 run scoreboard players set #timer siimpalone_timer 0

# Продолжение цикла
schedule function siimpalone:main_loop 1t replace
