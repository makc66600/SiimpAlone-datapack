# SiimpAlone - Spawn Myth
# Выбор и спавн мифического существа с балансом

# Сброс счета хаоса
scoreboard players set @s siimpalone_chaos 0

# Проверка времени суток для баланса
execute store result score #is_night is_night run time query daytime

# НОЧЬ (12000-23000): большая вероятность появления мифов
execute if score #is_night is_night matches 12000..23000 run function siimpalone:spawn_night_myth

# ДЕНЬ (0-11999): меньшая вероятность
execute if score #is_night is_night matches 0..11999 run function siimpalone:spawn_day_myth
