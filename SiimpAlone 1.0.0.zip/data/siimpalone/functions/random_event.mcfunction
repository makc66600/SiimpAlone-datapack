# SiimpAlone - Random Event
# Случайные события

# Случайный выбор (1-3)
scoreboard players set #random_event siimpalone_spawn 0
execute store result score #random_event siimpalone_spawn run random value 1..3

# Событие 1: Телепорт игрока
execute if score #random_event siimpalone_spawn matches 1 as @a at @s run tp @s ^ ^ ^5

# Событие 2: Внезапный урон
execute if score #random_event siimpalone_spawn matches 2 as @a at @s run damage @s 2 minecraft:out_of_world

# Событие 3: Глобальное сообщение
execute if score #random_event siimpalone_spawn matches 3 run tellraw @a {"text":"Something is watching you...","color":"dark_gray","italic":true}
