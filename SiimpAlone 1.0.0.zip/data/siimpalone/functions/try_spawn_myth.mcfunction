# SiimpAlone - Try Spawn Myth
# Попытка спавна мифических существ с балансом

# Проверка хаоса у игрока - чем больше хаос, тем выше шанс
execute as @a at @s if score @s siimpalone_chaos matches 15.. run function siimpalone:spawn_myth

# Дополнительная проверка ночью при высоком хаосе
execute as @a at @s if score @s siimpalone_chaos matches 10.. if predicate siimpalone:light_check if score #is_night is_night matches 12000..23000 run function siimpalone:spawn_myth
