# SiimpAlone - Check Events
# Проверка игровых событий

# Проверка дня/ночи
execute store result score #is_night is_night run time query daytime
execute if score #is_night is_night matches 12000..23000 run scoreboard players set #night_check is_night 1
execute if score #is_night is_night matches 0..11999 run scoreboard players set #night_check is_night 0

# Проверка игроков в темноте
execute as @a at @s if predicate siimpalone:light_check run scoreboard players add @s siimpalone_chaos 1
execute as @a at @s unless predicate siimpalone:light_check run scoreboard players set @s siimpalone_chaos 0

# Проверка одиночества игрока
execute as @a at @s unless entity @a[distance=1..30] run scoreboard players add @s siimpalone_chaos 2
